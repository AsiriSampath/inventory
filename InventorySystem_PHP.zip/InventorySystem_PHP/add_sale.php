<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha384-Dfz7q1r0I00i1hcf07U4srZ5eAqUC+1vNa2U+kqqfebs1IzxBLDT+6RGcXopE5vL" crossorigin="anonymous">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha384-A56SGWD7k8Ax+UmqNJ2Kxmbkm9k7Cj+yHjz0vHiw7sCTQKRgdaZM0YyKAYHRUi+o" crossorigin="anonymous"></script>
<?php
  $page_title = 'Add Sale';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
?>
<?php
  if (isset($_POST['add_sale'])) {
    $req_fields = array('s_id','payment_method', 'quantity', 'price','delivery_ammount','delivery_method','discount_amount', 'description', 'total','customer_name','customer_email','customer_phone','address','place_by', 'date');
    validate_fields($req_fields);
  
    if (empty($errors)) {
      $p_id      = $db->escape((int)$_POST['s_id']);
      $s_payment_method      = $db->escape($_POST['payment_method']);
      $s_qty     = $db->escape((int)$_POST['quantity']);
      $s_delivery_ammount      = $db->escape($_POST['delivery_ammount']);
      $s_delivery_method      = $db->escape($_POST['delivery_method']);
      $s_discount_amount = $db->escape($_POST['discount_amount']);
      $s_description = $db->escape($_POST['description']);
      $s_total   = $db->escape($_POST['total']);
      $s_customer_name   = $db->escape($_POST['customer_name']);
      $s_customer_email   = $db->escape($_POST['customer_email']);
      $s_customer_phone   = $db->escape($_POST['customer_phone']);
      $s_address  = $db->escape($_POST['address']);
      $s_place  = $db->escape($_POST['place_by']);
      if ($s_delivery_method === 'COD') {
        $s_place = $_POST['drivers-id'];
    }
      $date      = $db->escape($_POST['date']);
      $s_date    = make_date();
      $s_added = $_SESSION['gname'];
      $s_uid = $_SESSION['uid'];
  
      // Check if the product is out of stock
      $product = find_by_id('products', $p_id);
      $product_quantity = remove_junk($product['quantity']);
  
      if ($product_quantity <= 0) {
        echo "
          <script>
            Swal.fire({
              icon: 'error',
              title: 'Product is out of stock',
              text: 'Can\'t add sale. The product is out of stock.',
            }).then(() => {
                window.location.href = 'add_sale.php';
            });
          </script>
        ";
        exit(); // Stop execution to prevent further processing
      } else {
        $sql  = "INSERT INTO sales (";
        $sql .= " product_id, payment_method, qty, delivery_ammount, delivery_method, discount_amount, description, price, customer_name, added_by, user_id, customer_email, customer_phone, address, place_by, date";
        $sql .= ") VALUES (";
        $sql .= "'{$p_id}', '{$s_payment_method}', '{$s_qty}', '{$s_delivery_ammount}', '{$s_delivery_method}', '{$s_discount_amount}', '{$s_description}', '{$s_total}', '{$s_customer_name}','{$s_added}','{$s_uid}', '{$s_customer_email}', '{$s_customer_phone}','{$s_address}','{$s_place}','{$s_date}'";
        $sql .= ")";
  
        if ($db->query($sql)) {
          update_product_qty($s_qty, $p_id);
          // Success
          echo "<script>
            Swal.fire({
              icon: 'success',
              title: 'Sale added!',
              showConfirmButton: false,
              timer: 1500,
              didClose: () => {
                window.location.href = 'add_sale.php';
              }
            });
          </script>";
        } else {
          // Failure
          echo "<script>
            Swal.fire({
              icon: 'error',
              title: 'Failed to add sale!',
              showConfirmButton: false,
              timer: 1500,
              didClose: () => {
                window.location.href = 'add_sale.php';
              }
            });
          </script>";
        }
      }
  } else {
      $session->msg("d", $errors);
      redirect('add_sale.php', false);
    }
  }  
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="container-fluid">
    <?php echo display_msg($msg); ?>
    <form method="post" action="ajax.php" autocomplete="off" id="sug-form">
        <div class="form-group">
          <div class="input-group">
            <span class="input-group-btn">
              <button type="submit" class="btn btn-primary">Find <i class="fa fa-search" aria-hidden="true"></i></button>
            </span>
            <input type="text" id="sug_input" class="form-control" name="title"  placeholder="Search for product name">
         </div>
         <div id="result" class="list-group"></div>
        </div>
    </form>
  </div>
</div>
<div class="row">
  <div class="container-fluid">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Sale Add</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_sale.php">
          <div class="table-container">
            <table class="table table-bordered">
              <thead>
              <style>
                
                /* Adjust the width for each column separately */
                .col-item {
                  width: 15%; /* Width for Item column */
                }

                .col-price {
                  width: 10%; /* Width for Price column */
                }

                .col-payment-method {
                  width: 10%; /* Width for Payment Method column */
                }

                .col-Qty {
                  width: 5%; /* Width for qty column */
                }

                .col-Delivery-Amount {
                  width: 10%; /* Width for Delivery-Amount column */
                }

                .col-Delivery-Method {
                  width: 10%; /* Width for Delivery-Method column */
                }
                
                .col-Discount-Amount {
                  width: 10%; /* Width for Discount-Amount column */
                }

                .col-Description {
                  width: 15%; /* Width for Description column */
                }

                .col-Total {
                  width: 10%; /* Width for Total column */
                }

                .col-Customer-Name {
                  width: 15%; /* Width for Customer-Name column */
                }

                .col-Customer-Email {
                  width: 15%; /* Width for Customer-Email column */
                }

                .col-Customer-Phone {
                  width: 15%; /* Width for Customer-Email column */
                }

                .col-Address {
                  width: 20%; /* Width for Address column */
                }

                .col-Date {
                  width: 10%; /* Width for Date column */
                }

                .col-Action {
                  width: 10%; /* Width for Action column */
                }
              </style>

                <th class="col-item">Item</th>
                <th class="col-Price">Price</th>
                <th class="col-Payment-Method">Payment Method</th>
                <th class="col-Qty">Qty</th>
                <th class="col-Delivery-Amount">Delivery Amount</th>
                <th class="col-Delivery-Method">
                  Delivery Method
                  <button type="button" class="btn btn-info btn-xs" onclick="showDeliveryMethodAlert()">
                    <span class="glyphicon glyphicon-question-sign"></span>
                  </button>
                  <script>
                      function showDeliveryMethodAlert() {
                        Swal.fire({
                          icon: 'info',
                          title: 'Important Note',
                          text: 'If you select COD here, the delivery drivers dropdown will be added. Be sure to select a drivers name',
                        });
                      }
                    </script>
                </th>
                <th class="col-Discount-Amount" id="deliveryDriversHeader" style="display:none">Delivery Drivers</th>
                <th class="col-Discount-Amount">Discount Amount</th>
                <th class="col-Description">
                  Description
                  <button type="button" class="btn btn-info btn-xs" onclick="showDescriptionAlert()">
                  <span class="glyphicon glyphicon-question-sign"></span>
                  </button>
                  <script>
                  function showDescriptionAlert() {
                    Swal.fire({
                      icon: 'info',
                      title: 'Important Note',
                      text: 'Be sure to satate the reason for each discount you add here',
                    });
                  }
                </script>
                </th>
                <th class="col-Total">Total</th>
                <th class="col-Customer-Name">Customer Name</th>
                <th class="col-Customer-Email">Customer Email</th>
                <th class="col-Customer-Phone">Customer Phone</th>
                <th class="col-Address">Address</th>
                <th class="col-Address">SaleFor</th>
                <th class="col-Date">Date</th>
                <th class="col-Action">Action</i></th>
              </thead>
              <tbody id="product_info">
              <tbody id="product_info">
                <!-- Add multiple rows for each sale -->
                <tr>
                  <td>
                    <input type="text" class="form-control" name="s_id[]" placeholder="Product ID">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="price[]" placeholder="Price">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="payment_method[]" placeholder="Payment Method">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="quantity[]" placeholder="Quantity">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="delivery_ammount[]" placeholder="Delivery Amount">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="delivery_method[]" placeholder="Delivery Method">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="discount_amount[]" placeholder="Discount Amount">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="description[]" placeholder="Description">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="total[]" placeholder="Total">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="customer_name[]" placeholder="Customer Name">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="customer_email[]" placeholder="Customer Email">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="customer_phone[]" placeholder="Customer Phone">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="address[]" placeholder="Address">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="place_by[]" placeholder="Sale For">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="date[]" placeholder="Date">
                  </td>
                  <td>
                    <button class="btn btn-danger btn-xs" onclick="removeRow(this)" type="button">Remove</button>
                  </td>
                </tr>
              </tbody>

              </tbody>
            </table>
          </div>
          <button class="btn btn-success" onclick="addRow()" type="button">Add Sale</button>
          <button type="submit" name="add_sale" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
<!-- <script>
  var rowCounter =0;

  function addRow() {
    rowCounter++;

    var row = `
      <tr>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][s_id]" placeholder="Product ID">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][price]" placeholder="Price">
        </td>
        <td>
                  <select class="form-control" name="sales[${rowCounter}][payment_method]" placeholder="Payment Method">
                    <option value="cash">Cash</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="bank_transfer">Bank Transfer</option>
                  </select>
                </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][quantity]" placeholder="Quantity">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][delivery_ammount]" placeholder="Delivery Amount">
        </td>
        <td>
            <select class="form-control" name="sales[${rowCounter}][delivery_method]" placeholder="Delivery Method">
              <option value="cash">Cash</option>
              <option value="credit_card">COD</option>
              <option value="bank_transfer">Bank Transfer</option>
            </select>
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][discount_amount]" placeholder="Discount Amount">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][description]" placeholder="Description">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][total]" placeholder="Total">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][customer_name]" placeholder="Customer Name">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][customer_email]" placeholder="Customer Email">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][customer_phone]" placeholder="Customer Phone">
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][address]" placeholder="Address">
        </td>
        <td>
          <select class="form-control" name="sales[${rowCounter}][place_by]">
            <?php
              // // Retrieve all users
              // $users = find_all_user();

              // // Create an associative array to group users by their group names
              // $userGroups = array();
              // foreach ($users as $user) {
              //     $group = $user['group_name'];
              //     if (!isset($userGroups[$group])) {
              //         $userGroups[$group] = array();
              //     }
              //     $userGroups[$group][] = $user;
              // }

              // // Loop through the user groups and populate the sub-dropdowns
              // foreach ($userGroups as $group => $groupUsers) {
              //     echo "<optgroup label=\"$group\">";
              //     foreach ($groupUsers as $user) {
              //         echo "<option value=\"" . $user['name'] . "\">" . $user['name'] . "</option>";
              //     }
              //     echo "</optgroup>";
              // }
            ?>
          </select>
        </td>
        <td>
          <input type="text" class="form-control" name="sales[${rowCounter}][date]" placeholder="Date">
        </td>
        <td>
          <button class="btn btn-danger btn-xs" onclick="removeRow(this)" type="button">Remove</button>
        </td>
      </tr>
    `;
     

    document.getElementById("product_info").innerHTML += row;
  }

  function removeRow(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
  }
</script> -->
<script>
  var rowCounter = 0;

  function addRow() {
    rowCounter++;

    var row = `
      <tr>
        <td>
          <input type="text" class="form-control" name="s_id[]" placeholder="Product ID">
        </td>
        <td>
          <input type="text" class="form-control" name="price[]" placeholder="Price">
        </td>
        <td>
          <input type="text" class="form-control" name="payment_method[]" placeholder="Payment Method">
        </td>
        <td>
          <input type="text" class="form-control" name="quantity[]" placeholder="Quantity">
        </td>
        <td>
          <input type="text" class="form-control" name="delivery_ammount[]" placeholder="Delivery Amount">
        </td>
        <td>
          <input type="text" class="form-control" name="delivery_method[]" placeholder="Delivery Method">
        </td>
        <td>
          <input type="text" class="form-control" name="discount_amount[]" placeholder="Discount Amount">
        </td>
        <td>
          <input type="text" class="form-control" name="description[]" placeholder="Description">
        </td>
        <td>
          <input type="text" class="form-control" name="total[]" placeholder="Total">
        </td>
        <td>
          <input type="text" class="form-control" name="customer_name[]" placeholder="Customer Name">
        </td>
        <td>
          <input type="text" class="form-control" name="customer_email[]" placeholder="Customer Email">
        </td>
        <td>
          <input type="text" class="form-control" name="customer_phone[]" placeholder="Customer Phone">
        </td>
        <td>
          <input type="text" class="form-control" name="address[]" placeholder="Address">
        </td>
        <td>
          <input type="text" class="form-control" name="place_by[]" placeholder="Sale For">
        </td>
        <td>
          <input type="text" class="form-control" name="date[]" placeholder="Date">
        </td>
        <td>
          <button class="btn btn-danger btn-xs" onclick="removeRow(this)" type="button">Remove</button>
        </td>
      </tr>
    `;

    document.getElementById("product_info").innerHTML += row;
  }

  function removeRow(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
  }
</script>