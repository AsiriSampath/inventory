<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  $page_title = 'Add User';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(1);
  $groups = find_all('user_groups');
?>
<?php
 if (isset($_POST['add_user'])) {
  $req_fields = array('full-name', 'username', 'password', 'email', 'phone_no', 'level');
  validate_fields($req_fields);

  if (empty($errors)) {
      $name = remove_junk($db->escape($_POST['full-name']));
      $username = remove_junk($db->escape($_POST['username']));
      $password = remove_junk($db->escape($_POST['password']));
      $email = remove_junk($db->escape($_POST['email']));
      $phone_no = remove_junk($db->escape($_POST['phone_no']));
      $user_level = (int)$db->escape($_POST['level']);
      $password = sha1($password);

      // Check if the username is already taken
      $username_check = find_by_sql("SELECT id FROM users WHERE username = '{$username}'");
    if ($username_check) {
        echo "
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Username Already Taken',
                    text: 'Username {$username} is already taken. Please choose a different username.',
                    timer: 1500,
                  }).then(() => {
                    window.location.href = 'add_user.php';
                });
            </script>";
        exit;
      }
      $email_check = find_by_sql("SELECT id FROM users WHERE email = '{$email}'");
      if ($email_check) {
          echo "
              <script>
                  Swal.fire({
                      icon: 'error',
                      title: 'Email Already Taken',
                      text: 'Email {$email} is already taken. Please choose a different email.',
                      timer: 1500,
                  }).then(() => {
                      window.location.href = 'add_user.php';
                  });
              </script>";
          exit;
      }

      $query = "INSERT INTO users (";
      $query .= "name,username,password,email,phone_no,user_level,status";
      $query .= ") VALUES (";
      $query .= " '{$name}', '{$username}', '{$password}', '{$email}', '{$phone_no}', '{$user_level}','1'";
      $query .= ")";

      if ($db->query($query)) {
          // User account created successfully
          echo "<script>
                Swal.fire({
                  icon: 'success',
                  title: 'User Account Created',
                  showConfirmButton: false,
                  timer: 1500,
                  didClose: () => {
                    window.location.href = 'add_user.php';
                  }
                });
              </script>";
      } else {
          // Failed to create user account
          echo "<script>
                Swal.fire({
                  icon: 'error',
                  title: 'Failed to Create Account',
                  showConfirmButton: false,
                  timer: 1500,
                  didClose: () => {
                    window.location.href = 'add_user.php';
                  }
                });
              </script>";
      }
  } else {
      $session->msg("d", $errors);
      redirect('add_user.php', false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
  <?php echo display_msg($msg); ?>
  <div class="row">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Add New User</span>
       </strong>
      </div>
      <div class="panel-body">
        <div class="col-md-6">
          <form method="post" action="add_user.php">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="full-name" placeholder="Full Name">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" placeholder="Username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name ="password"  placeholder="Password">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name ="email"  placeholder="Email">
            </div>
            <div class="form-group">
                <label for="phone_no">Phone Number</label>
                <input type="text" class="form-control" name ="phone_no"  placeholder="Phone Number">
            </div>
            <div class="form-group">
              <label for="level">User Role</label>
                <select class="form-control" name="level">
                  <?php foreach ($groups as $group ):?>
                   <option value="<?php echo $group['group_level'];?>"><?php echo ucwords($group['group_name']);?></option>
                <?php endforeach;?>
                </select>
            </div>
            <div class="form-group clearfix">
              <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
            </div>
        </form>
        </div>

      </div>

    </div>
  </div>

<?php include_once('layouts/footer.php'); ?>
