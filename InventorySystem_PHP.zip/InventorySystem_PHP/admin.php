<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory_system";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
// Create an array of all months
$months = array(
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
);

// SQL query to fetch the required data
$query = "SELECT MONTHNAME(date) AS month, SUM(qty) AS total_qty FROM sales GROUP BY MONTH(date)";

// Execute the query
$result = $conn->query($query);

// Fetch the data into an associative array
$data = array();
while ($row = $result->fetch_assoc()) {
    $month = $row['month'];
    $data['labels'][] = $month;
    $data['datasets'][0]['data'][] = $row['total_qty'];

    // Remove the fetched month from the array of all months
    $months = array_diff($months, array($month));
}

// Fill in the remaining months with zero values
foreach ($months as $month) {
    $data['labels'][] = $month;
    $data['datasets'][0]['data'][] = 0;
}
?>

<!-- pie chart code -->
<?php
// Create an array of all place_by values
$place_by_values = array();

// SQL query to fetch the required data
$query1 = "SELECT place_by, COUNT(*) AS total_sales FROM sales GROUP BY place_by";

// Execute the query
$result1 = $conn->query($query1);

// Fetch the data into an associative array
$data1 = array();
while ($row = $result1->fetch_assoc()) {
  $place_by = $row['place_by'];
  $place_by_values[] = $place_by;
  $data1['labels'][] = $place_by;
  $data1['datasets'][0]['data'][] = $row['total_sales'];
}


$unique_place_by_values = array_unique($place_by_values);
$missing_place_by_values = array_diff($unique_place_by_values, isset($data1['labels']) ? $data1['labels'] : array());

foreach ($missing_place_by_values as $place_by) {
  $data1['labels'][] = $place_by;
  $data1['datasets'][0]['data'][] = 0;
}
?>
<?php
// Close the database connection
$conn->close();
?>

<?php
  $page_title = 'Admin Home Page';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(5);
?>
<?php
 $c_categorie     = count_by_id('categories');
 $c_product       = count_by_id('products');
 $c_sale          = count_by_id('sales');
 $c_user          = count_by_id('users');
 $products_sold   = find_higest_saleing_product('10');
 $recent_products = find_recent_product_added('5');
 $recent_sales    = find_recent_sale_added('5')
?>
<?php include_once('layouts/header.php'); ?>
<style>
  /* Panel styles */
  .panel {
    margin-bottom: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .panel-heading {
    padding: 10px 15px;
    background-color: #f5f5f5;
    border-bottom: 1px solid #ddd;
    border-radius: 4px 4px 0 0;
    font-size: 16px;
    font-weight: bold;
  }

  .panel-body {
    padding: 15px;
  }
  .panel {
  /* Existing styles... */
  transform: scale(1);
  transition: transform 0.3s;
}

.panel:hover {
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
  transform: scale(1.05); /* Adjust the scale factor as needed */
}
  /* Table styles */
  .table {
    width: 100%;
    margin-bottom: 0;
    color: #333;
    font-size: 14px;
  }

  .table th,
  .table td {
    padding: 8px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 1px solid #ddd;
  }

  .table th {
    font-weight: bold;
    background-color: #f9f9f9;
  }

  .table-condensed th,
  .table-condensed td {
    padding: 4px 8px;
  }
 table tbody tr:hover {
  background-color: #f5f5f5;
}

.table tbody tr:hover td {
  color: #000;
}
  /* Animation styles */
  @keyframes fadeIn {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }

  .animated {
    animation-duration: 1s;
    animation-fill-mode: both;
  }

  .fadeIn {
    animation-name: fadeIn;
  }
    /* Adjusting responsiveness for smaller screens */
    @media (max-width: 768px) {
    /* Reduce padding and font size for smaller screens */
    .panel-heading {
      padding: 5px 10px;
      font-size: 14px;
    }

    .table th,
    .table td {
      padding: 6px 8px;
      font-size: 12px;
    }

    .table-condensed th,
    .table-condensed td {
      padding: 2px 4px;
    }

    /* Make panels stack vertically on smaller screens */
    .col-md-3.animated {
      width: 100%;
    }

    /* Center-align text in panels */
    .panel-value {
      text-align: center;
    }
  }

  /* Adjusting responsiveness for very small screens (e.g., smartphones) */
  @media (max-width: 576px) {
    /* Reduce padding for headings and table cells */
    .panel-heading {
      padding: 5px;
    }

    .table th,
    .table td {
      padding: 4px;
    }
  }
</style>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<?php if ($user['user_level'] === '1'): ?>
  <div class="row">
    <a href="users.php" style="color: black;">
      <div class="col-md-3 animated fadeIn">
        <div class="panel panel-box clearfix">
          <div class="panel-icon pull-left bg-secondary1">
            <i class="glyphicon glyphicon-user"></i>
          </div>      
          <div class="panel-value pull-right">
            <h2 class="margin-top"><?php echo $c_user['total']; ?></h2>
            <p class="text-muted">Users</p>
          </div>
        </div>
      </div>
    </a>
  <?php endif; ?>

  <?php if ($user['user_level'] === '1' || $user['user_level'] === '2'): ?>
    <a href="categorie.php" style="color: black;">
      <div class="col-md-3 animated fadeIn">
        <div class="panel panel-box clearfix">
          <div class="panel-icon pull-left bg-red">
            <i class="glyphicon glyphicon-th-large"></i>
          </div>
          <div class="panel-value pull-right">
            <h2 class="margin-top"><?php echo $c_categorie['total']; ?></h2>
            <p class="text-muted">Categories</p>
          </div>
        </div>
      </div>
    </a>
    <?php endif; ?>

    <a href="product.php" style="color: black;">
      <div class="col-md-3 animated fadeIn">
        <div class="panel panel-box clearfix">
          <div class="panel-icon pull-left bg-blue2">
            <i class="glyphicon glyphicon-shopping-cart"></i>
          </div>
          <div class="panel-value pull-right">
            <h2 class="margin-top"><?php echo $c_product['total']; ?></h2>
            <p class="text-muted">Products</p>
          </div>
        </div>
      </div>
    </a>
	
  <a href="sales.php" style="color: black;">
    <div class="col-md-3 animated fadeIn">
      <div class="panel panel-box clearfix">
        <div class="panel-icon pull-left bg-green">
          <i class="glyphicon glyphicon-usd"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"><?php echo $c_sale['total']; ?></h2>
          <p class="text-muted">Sales</p>
        </div>
      </div>
    </div>
  </a>
</div>

<div class="graphbox">
  <div class="box animated fadeIn">
    <canvas id="pieChart" class="chart-container"></canvas>
    <script>
      // Get the canvas element
      var ctx = document.getElementById('pieChart').getContext('2d');

      var data = <?php echo json_encode($data1); ?>;

      // Create the pie chart
      var pieChart = new Chart(ctx, {
        type: 'pie',
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      });
    </script>
  </div>
  
  <div class="box animated fadeIn">
    <canvas id="barChart" class="chart-container"></canvas>
    <script>
      // Get the canvas element
      var ctx = document.getElementById('barChart').getContext('2d');

      // Define the data for the chart
      var data = <?php echo json_encode($data); ?>;

      // Customize the colors of the bars
      data.datasets.forEach(function(dataset) {
        dataset.backgroundColor = 'rgba(238, 75, 43)'; 
        dataset.borderColor = 'rgba(255, 99, 132, 1)'; 
      });

      // Create the bar chart
      var barChart = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true
            }
          },
          plugins: {
            legend: {
              display: false
            }
          }
        }
      });
    </script>
  </div>
</div>

<div class="row">
  <div class="col-md-4 animated fadeIn">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Highest Selling Products</span>
        </strong>

        </div>
      <div class="panel-body">
        <table class="table table-striped table-bordered table-condensed">
          <thead>
            <tr>
              <th>Title</th>
              <th>Total Sold</th>
              <th>Total Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products_sold as  $product_sold): ?>
              <tr>
                <td><?php echo remove_junk(first_character($product_sold['name'])); ?></td>
                <td><?php echo (int)$product_sold['totalSold']; ?></td>
                <td><?php echo (int)$product_sold['totalQty']; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          </table>
      </div>
    </div>
  </div>
  <div class="col-md-4 animated fadeIn">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>LATEST SALES</span>
        </strong>
        </div>
        <div class="panel-body">
        <table class="table table-striped table-bordered table-condensed">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th>Product Name</th>
              <th>Date</th>
              <th>Total Sale</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_sales as  $recent_sale): ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td>
                  <a href="edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
                    <?php echo remove_junk(first_character($recent_sale['name'])); ?>
                  </a>
                </td>
                <td><?php echo remove_junk(ucfirst($recent_sale['date'])); ?></td>
                <td>$<?php echo remove_junk(first_character($recent_sale['price'])); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          </table>
      </div>
    </div>
  </div>
  <div class="col-md-4 animated fadeIn">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Recently Added Products</span>
        </strong>
      </div>
      <div class="panel-body">

        <div class="list-group">
      <?php foreach ($recent_products as  $recent_product): ?>
            <a class="list-group-item clearfix" href="edit_product.php?id=<?php echo    (int)$recent_product['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_product['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_product['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_product['name']));?>
                  <span class="label label-warning pull-right">
                 <?php echo (int)$recent_product['sale_price']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_product['categorie'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>
 </div>
  <div class="row">
  </div>
<?php include_once('layouts/footer.php'); ?>
