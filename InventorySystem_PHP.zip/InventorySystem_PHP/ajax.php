<?php
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);}
?>
<?php
 // Auto suggetion
 $html = '';
 if (isset($_POST['product_name']) && strlen($_POST['product_name'])) {
     $products = find_product_by_title($_POST['product_name']);
     if ($products) {
         foreach ($products as $product) {
             $html .= "<li class=\"list-group-item\">";
             $html .= $product['name'];
             $html .= "</li>";
         }
     } else {
         // Escape the string properly using addslashes()
         $notFoundMessage = "Not found";
         $html .= '<li onClick="fill(\'' . addslashes($notFoundMessage) . '\')" class="list-group-item">';
         $html .= $notFoundMessage;
         $html .= "</li>";
     }
 
     echo json_encode($html);
 }
 ?>
 <?php
// find all product
if (isset($_POST['p_name']) && strlen($_POST['p_name'])) {
    $product_title = remove_junk($db->escape($_POST['p_name']));
    if ($results = find_all_product_info_by_title($product_title)) {
        foreach ($results as $result) {

            $html .= "<td id=\"s_name\">" . $result['name'] . "</td>";
            $html .= "<input type=\"hidden\" name=\"s_id\" value=\"{$result['id']}\">";
            $html .= "<td>";
            $html .= "<input type=\"text\" class=\"form-control\" name=\"price\" value=\"{$result['sale_price']}\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<select class=\"form-control\" name=\"payment_method\">";
            $html .= "<option value=\"cash\">Cash</option>";
            $html .= "<option value=\"credit_card\">C.Card</option>";
            $html .= "<option value=\"bank_transfer\">B.Transfer</option>";
            $html .= "</select>";
            $html .= "</td>";
            $html .= "<td id=\"s_qty\">";
            $html .= "<input type=\"text\" class=\"form-control\" name=\"quantity\" value=\"1\">";
            $html .= "</td>";
            $html .= '<td>';
            $html .= '<input type="text" class="form-control" name="delivery_ammount" placeholder="D. Amount" onchange="calculateTotal()">';
            $html .= '</td>';                      
            $html .= "<td>";
            $html .= "<select class=\"form-control\" name=\"delivery_method\" onchange=\"toggleDriverSelect(this)\">";
            $html .= "<option value=\"cash\">Cash</option>";
            $html .= "<option value=\"bank_transfer\">B.Transfer</option>";
            $html .= "<option value=\"COD\">COD</option>";
            $html .= "</select>";
            $html .= "</td>";
            $html .= "<td id=\"driverSelect\" style=\"display:none\">";
            $html .= "<select class=\"form-control\" name=\"drivers-id\">";
            $deliveryDrivers = find_all_delivery_drivers('delivery_driver');
            $html .= "<option value=\"all\">All Drivers</option>";
            foreach ($deliveryDrivers as $driver) {
                $html .= "<option value=\"" . $driver['name'] . "\">" . $driver['name'] . "</option>";
            }
            $html .= "</select>";
            $html .= "</td>";
            
            $html .= "<script>
            function toggleDriverSelect(select) {
                var driverSelect = document.getElementById('driverSelect');
                if (select.value === 'COD') {
                    driverSelect.style.display = 'block';
                    document.getElementById('deliveryDriversHeader').style.display = 'table-cell'; // Show the Delivery Drivers header
                } else {
                    driverSelect.style.display = 'none';
                    document.getElementById('deliveryDriversHeader').style.display = 'none'; // Hide the Delivery Drivers header
                }
            }
            </script>";
            
            $html .= '<td>';
            $html .= '<input type="text" class="form-control" name="discount_amount" placeholder="Discount Amount" oninput="toggleDescriptionBox(); calculateTotal();" onchange="validateFields()">';
            $html .= '</td>';         
            $html .= '<td>';
            $html .= '<textarea class="form-control" name="description" id="description" placeholder="Description" style="display: none; onchange="validateFields()"></textarea>';
            $html .= '</td>';
            $html .= '<script>';
            $html .= 'function toggleDescriptionBox() {';
            $html .= '  var discountAmount = document.getElementsByName("discount_amount")[0].value;';
            $html .= '  var descriptionBox = document.getElementById("description");';
            $html .= '  if (discountAmount !== "") {';
            $html .= '    descriptionBox.style.display = "block";'; 
            $html .= '  } else {';
            $html .= '    descriptionBox.style.display = "none";';   
            $html .= '  }';
            $html .= '}';
            $html .= '</script>';            
            $html .= "<td>";
            $html .= "<input type=\"text\" class=\"form-control\" name=\"total\" value=\"{$result['sale_price']}\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<input type=\"text\" class=\"form-control\" name=\"customer_name\" placeholder=\"Customer Name\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<input type=\"email\" class=\"form-control\" name=\"customer_email\" placeholder=\"Customer Email\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<input type=\"text\" class=\"form-control\" name=\"customer_phone\" placeholder=\"Customer Phone\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<input type=\"address\" class=\"form-control\" name=\"address\" placeholder=\"Address\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<select class=\"form-control\" name=\"place_by\">";

            // Retrieve all users
            $users = find_all_user();

            // Create an associative array to group users by their group names
            $userGroups = array();
            foreach ($users as $user) {
                $group = $user['group_name'];
                if (!isset($userGroups[$group])) {
                    $userGroups[$group] = array();
                }
                $userGroups[$group][] = $user;
            }

            // Loop through the user groups and populate the sub-dropdowns
            foreach ($userGroups as $group => $groupUsers) {
                $html .= "<optgroup label=\"$group\">";
                foreach ($groupUsers as $user) {
                    $html .= "<option value=\"" . $user['name'] . "\">" . $user['name'] . "</option>";
                }
                $html .= "</optgroup>";
            }

            $html .= "</select>";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<input type=\"date\" class=\"form-control datePicker\" name=\"date\" data-date data-date-format=\"yyyy-mm-dd\">";
            $html .= "</td>";
            $html .= "<td>";
            $html .= "<center>";
            $html .= '<button type="submit" name="add_sale" class="btn btn-primary">
            <i class="fa fa-plus-square" aria-hidden="true"></i>
         </button>';
            $html .= "</td>";
            $html .= "</center>";
            $html .= "</tr>";

        }
    } else {
        $html = '<tr><td>Product name is not registered in the database</td></tr>';
    }

    echo json_encode($html);
}
?>
