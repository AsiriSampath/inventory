<?php include_once('includes/load.php'); ?>
<?php
$req_fields = array('username','password' );
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

  if(empty($errors)){

    $user = authenticate($username, $password);

        if($user):
          $_SESSION['username']=$user['username'];
          $_SESSION['gname']=$user['group_name'];
          $_SESSION['uid']=$user['id'];
           //create session with id
           $session->login($user['id']);
           //Update Sign in time
           updateLastLogIn($user['id']);
           // redirect user to group home page by user level
           if($user['user_level'] === '1' || $user['user_level'] === '2'):
             $session->msg("s", "Hello ".$user['username'].", Welcome to Gadget Srilanka Inventory");
             redirect('admin.php',false);
           elseif ($user['user_level'] === '3' || $user['user_level'] === '4' || $user['user_level'] === '5'):
              $session->msg("s", "Hello ".$user['username'].", Welcome to Gadget Srilanka Inventory");
             redirect('admin_by_user.php',false);
           else:
              $session->msg("s", "Hello ".$user['username'].", Welcome to Gadget Srilanka Inventory");
             redirect('admin_by_user.php',false);
           endif;

        else:
          $session->msg("d", "Sorry Username/Password incorrect.");
          redirect('index.php',false);
        endif;

  } else {

     $session->msg("d", $errors);
     redirect('index.php',false);
  } 