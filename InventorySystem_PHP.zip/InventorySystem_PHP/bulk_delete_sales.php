<?php
// bulk_delete_sales.php

require_once('includes/load.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ids'])) {
  $saleIds = $_POST['ids'];

  foreach ($saleIds as $saleId) {
    // Perform the delete operation for each sale
    $result = delete_sale_by_id((int)$saleId);

    // Handle the result as needed
    // ...
  }

  // Return a response indicating the success of the operation
  echo json_encode(['success' => true]);
} else {
  // Return an error response
  echo json_encode(['success' => false]);
}
?>
