<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  $page_title = 'All categories';
  require_once('includes/load.php');
  // Checking what level user has permission to view this page
  page_require_level(5);
  
  $all_categories = find_all('categories');
?>
<?php
 if (isset($_POST['add_cat'])) {
  $req_field = array('categorie-name');
  validate_fields($req_field);
  $cat_name = remove_junk($db->escape($_POST['categorie-name']));
  if (empty($errors)) {
    // Check if the category name already exists
    $existing_category = find_by_sql("SELECT * FROM categories WHERE name='{$cat_name}' LIMIT 1");
    if ($existing_category) {
      // Category name already exists, show error message in SweetAlert2 pop-up
      echo "<script>
            document.addEventListener('DOMContentLoaded', function () {
              Swal.fire({
                icon: 'error',
                title: 'Category name already exists!',
                text: 'Please choose a different name.',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
              });
            });
          </script>";
    } else {
      // Category name is unique, proceed with adding the category
      $sql = "INSERT INTO categories (name) VALUES ('{$cat_name}')";
      if ($db->query($sql)) {
        // Category added successfully
        echo "<script>
          Swal.fire({
            icon: 'success',
            title: 'Successfully Added New Category',
            showConfirmButton: false,
            timer: 1500,
            didClose: () => {
              window.location.href = 'categorie.php';
            }
          });
        </script>";
      } else {
        // Failed to insert category
        echo "<script>
          Swal.fire({
            icon: 'error',
            title: 'Sorry! Failed To Insert',
            showConfirmButton: false,
            timer: 1500,
            didClose: () => {
              window.location.href = 'categorie.php';
            }
          });
        </script>";
      }
    }
  } else {
    $session->msg("d", $errors);
    redirect('categorie.php', false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-5">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Add New Category</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="categorie.php">
          <div class="form-group">
            <input type="text" class="form-control" name="categorie-name" placeholder="Category Name">
          </div>
          <button type="submit" name="add_cat" class="btn btn-primary">
            <i class="fa fa-plus-square" aria-hidden="true"></i>
        </button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>All Categories</span>
        </strong>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">#</th>
                <th>Categories</th>
                <?php if ($user['user_level'] === '1' || $user['user_level'] === '2'): ?>
                <th class="text-center" style="width: 100px;">Actions</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($all_categories as $cat) : ?>
                <tr>
                  <td class="text-center"><?php echo count_id(); ?></td>
                  <td><?php echo remove_junk(ucfirst($cat['name'])); ?></td>
                    <td class="text-center">
                      <div class="btn-group">
                        <a href="edit_categorie.php?id=<?php echo (int)$cat['id']; ?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                          <span class="glyphicon glyphicon-edit"></span>
                        </a>
                        <?php if ($user['user_level'] === '1') : ?>
                        <a href="#" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove" onclick="confirmDelete(<?php echo (int)$cat['id']; ?>)">
                          <span class="glyphicon glyphicon-trash"></span>
                        </a>
                        <script>
                          function confirmDelete(productId) {
                            Swal.fire({
                              title: 'Are you sure?',
                              text: 'You will not be able to recover this Categorie!',
                              icon: 'warning',
                              showCancelButton: true,
                              confirmButtonColor: '#3085d6',
                              cancelButtonColor: '#d33',
                              confirmButtonText: 'Yes, delete it!'
                            }).then((result) => {
                              if (result.isConfirmed) {
                                // User confirmed the delete action
                                // Redirect to delete_product.php with the product ID
                                window.location.href = 'delete_categorie.php?id=' + productId;
                              }
                            });
                          }
                        </script>
                      </div>
                    </td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
