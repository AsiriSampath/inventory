<?php
$page_title = 'Customer Report';
require_once('includes/load.php');
page_require_level(2);
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-6">
    <div class="panel">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Generate Customer Report</span>
        </strong>
      </div>
      <div class="panel-body">
        <form id="customer-report-form" class="clearfix" method="post" action="customers_report_process.php">
          <div class="form-group">
            <label class="form-label">Customer Field</label>
            <div class="checkbox">
              <label>
                <input type="checkbox" name="customer-field[]" value="customer_name">
                Name
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" name="customer-field[]" value="customer_email">
                Email
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" name="customer-field[]" value="customer_phone">
                Phone Number
              </label>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" name="customer-field[]" value="address">
                Address
              </label>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Date Range</label>
            <div class="input-group">
              <input type="date" class="form-control" name="start-date" placeholder="From">
              <span class="input-group-addon"><i class="glyphicon glyphicon-menu-right"></i></span>
              <input type="date" class="form-control" name="end-date" placeholder="To">
            </div>
          </div>
          <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary">Generate Report <i class="fa fa-cogs" aria-hidden="true"></i></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Include SweetAlert2 library -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('customer-report-form');
  form.addEventListener('submit', function(event) {
    var customerFields = form.querySelectorAll('input[name="customer-field[]"]:checked');
    if (customerFields.length === 0) {
      event.preventDefault();
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Please select at least one customer field.',
      });
    }
  });
});
</script>
<style>
.panel {
  margin-top: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.panel-heading {
  background-color: #fdfaf3;
  border-bottom: 2px solid #364c6f;
  padding: 10px;
}

.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 18px;
}

.panel-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-label {
  font-weight: bold;
}

.form-control {
  width: 100%;
}
@media (max-width: 768px) {
  .col-md-6 {
    width: 100%;
  }
}
</style>
<?php include_once('layouts/footer.php'); ?>
