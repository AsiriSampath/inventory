<?php
$page_title = 'Customer Report';
$results = '';
require_once('includes/load.php');
page_require_level(2);

if (isset($_POST['submit'])) {
  $req_dates = array('start-date', 'end-date');
  validate_fields($req_dates);

  if (empty($errors)) {
    $start_date = remove_junk($db->escape($_POST['start-date']));
    $end_date = remove_junk($db->escape($_POST['end-date']));
    $all_customers = find_all_customer_details();
    $selected_fields = isset($_POST['customer-field']) ? $_POST['customer-field'] : array();

    // Filter the customers based on the date range
    $filtered_customers = array();
    foreach ($all_customers as $customer) {
      $customer_date = strtotime($customer['date']); // Replace 'date' with the actual date column name in your database table
      if ($customer_date >= strtotime($start_date) && $customer_date <= strtotime($end_date)) {
        $filtered_customer = array();
        foreach ($selected_fields as $field) {
          if (isset($customer[$field])) {
            $filtered_customer[$field] = $customer[$field];
          }
        }
        $filtered_customers[] = $filtered_customer;
      }
    }
  } else {
    $session->msg("d", $errors);
    redirect('customer_report.php', false);
  }
} else {
  $session->msg("d", "Please select dates and customer fields.");
  redirect('customer_report.php', false);
}
?>

<!doctype html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title><?php echo date('Y-m-d') . ' ' . ' Customer Report'; ?></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>
  <style>
      @media print {
     html,body{
        font-size: 9.5pt;
        margin: 0;
        padding: 0;
     }.page-break {
       page-break-before:always;
       width: auto;
       margin: auto;
      }
    }
    .page-break{
      width: 980px;
      margin: 0 auto;
    }
     .sale-head{
       margin: 40px 0;
       text-align: center;
     }.sale-head h1,.sale-head strong{
       padding: 10px 20px;
       display: block;
     }.sale-head h1{
       margin: 0;
       border-bottom: 1px solid #212121;
     }.table>thead:first-child>tr:first-child>th{
       border-top: 1px solid #000;
      }
      table thead tr th {
       text-align: center;
       border: 1px solid #ededed;
     }table tbody tr td{
       vertical-align: middle;
     }.sale-head,table.table thead tr th,table tbody tr td,table tfoot tr td{
       border: 1px solid #212121;
       white-space: nowrap;
     }.sale-head h1,table thead tr th,table tfoot tr td{
       background-color: #f8f8f8;
     }tfoot{
       color:#000;
       text-transform: uppercase;
       font-weight: 500;
     }
  </style>
</head>
<body>
<style>
        @media print {
          .text-center {
            display: none;
          }
        }
      </style>

      <div class="text-center">
        <button onclick="printReport()" class="btn btn-primary">Print Report</button>
      </div>

      <script>
        function printReport() {
          window.print();
        }
      </script>
  <div class="container">
    <h2>Customer Report - <?php echo $start_date . ' to ' . $end_date; ?></h2>
    <table class="table table-bordered">
      <thead>
        <tr>
          <?php foreach ($selected_fields as $field): ?>
            <th><?php echo ucfirst($field); ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($filtered_customers as $customer): ?>
          <tr>
            <?php foreach ($selected_fields as $field): ?>
              <td><?php echo isset($customer[$field]) ? $customer[$field] : ''; ?></td>
            <?php endforeach; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
