<?php
// Replace "your_hostname", "your_username", "your_password", and "your_database" with your actual MySQL credentials
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "inventory_system";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
