<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(1);
?>
<?php
  $categorie = find_by_id('categories',(int)$_GET['id']);
  if(!$categorie){
    $session->msg("d","Missing Categorie id.");
    redirect('categorie.php');
  }
?>
<?php
  $delete_id = delete_by_id('categories',(int)$categorie['id']);
$categorieId = $_GET['id'];
if ($delete_id) {
  // Category Deleted
  echo "<script>
        Swal.fire({
          icon: 'success',
          title: 'Category Deleted',
          showConfirmButton: false,
          timer: 1500,
        }).then(() => {
            window.location.href = 'categorie.php';
        });
      </script>";
} else {
  // Category Deletion Failed
  echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Category Deletion Failed',
          showConfirmButton: false,
          timer: 1500,
        }).then(() => {
            window.location.href = 'categorie.php';
        });
      </script>";
}
?>
