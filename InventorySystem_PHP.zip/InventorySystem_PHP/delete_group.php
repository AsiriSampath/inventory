<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
$delete_id = delete_by_id('user_groups', (int)$_GET['id']);
$groupId = $_GET['id'];
if ($delete_id) {
  // Group Deleted
  echo "<script>
        Swal.fire({
          icon: 'success',
          title: 'Group Deleted',
          showConfirmButton: false,
          timer: 1500,
        }).then(() => {
            window.location.href = 'group.php';
        });
      </script>";
} else {
  // Group Deletion Failed Or Missing Parameter
  echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Group Deletion Failed Or Missing Parameter',
          showConfirmButton: false,
          timer: 1500,
        }).then(() => {
            window.location.href = 'group.php';
        });
      </script>";
}
?>

