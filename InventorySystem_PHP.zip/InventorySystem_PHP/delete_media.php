<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(6);
?>
<?php
$mediaId = $_GET['id'];
// Perform the deletion process here

$find_media = find_by_id('media', (int)$mediaId);
$photo = new Media();

if ($photo->media_destroy($find_media['id'], $find_media['file_name'])) {
  // Success
  echo "<script>
    Swal.fire({
      icon: 'success',
      title: 'Photo has been deleted!',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'media.php';
    });
  </script>";
} else {
  // Failure
  echo "<script>
    Swal.fire({
      icon: 'error',
      title: 'Photo deletion failed or missing parameters.',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'media.php';
    });
  </script>";
}
?>

