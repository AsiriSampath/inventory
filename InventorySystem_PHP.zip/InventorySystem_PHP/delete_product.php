<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(2);
?>
<?php
  $product = find_by_id('products',(int)$_GET['id']);
  if(!$product){
    $session->msg("d","Missing Product id.");
    redirect('product.php');
  }
?>
<?php
$productId = $_GET['id'];
// Perform the deletion process here

$delete_id = delete_by_id('products', (int)$productId);

if ($delete_id) {
  // Products deleted successfully
  echo "<script>
    Swal.fire({
      icon: 'success',
      title: 'Products deleted!',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'product.php';
    });
  </script>";
} else {
  // Products deletion failed
  echo "<script>
    Swal.fire({
      icon: 'error',
      title: 'Products deletion failed!',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'product.php';
    });
  </script>";
}
?>

