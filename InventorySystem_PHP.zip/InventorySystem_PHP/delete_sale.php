<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(3);
?>
<?php
  $d_sale = find_by_id('sales',(int)$_GET['id']);
  if(!$d_sale){
    $session->msg("d","Missing sale id.");
    redirect('sales.php');
  }
?>
<?php
$saleId = $_GET['id'];
// Perform the deletion process here

$delete_id = delete_by_id('sales', (int)$saleId);

if ($delete_id) {
  // Success
  echo "<script>
    Swal.fire({
      icon: 'success',
      title: 'Sale deleted!',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'sales.php';
    });
  </script>";
} else {
  // Failure
  echo "<script>
    Swal.fire({
      icon: 'error',
      title: 'Sale deletion failed!',
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
        window.location.href = 'sales.php';
    });
  </script>";
}
?>

