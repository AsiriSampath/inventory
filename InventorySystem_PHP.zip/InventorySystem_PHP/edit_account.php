<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
$page_title = 'Edit Account';
require_once('includes/load.php');
page_require_level(5);
?>

<?php
// Update user image
if (isset($_POST['submit'])) {
  $photo = new Media();
  $user_id = (int)$_POST['user_id'];
  $photo->upload($_FILES['file_upload']);
  if ($photo->process_user($user_id)) {
    // Success
    echo "<script>
      Swal.fire({
        icon: 'success',
        title: 'Photo uploaded!',
        showConfirmButton: false,
        timer: 1500,
        didClose: () => {
          window.location.href = 'edit_account.php';
        }
      });
    </script>";
  } else {
    // Failure
    echo "<script>
      Swal.fire({
        icon: 'error',
        title: 'Failed to upload photo',
        html: '" . join($photo->errors) . "',
        showConfirmButton: false,
        timer: 3000,
        didClose: () => {
          window.location.href = 'edit_account.php';
        }
      });
    </script>";
  }
}
?>

<?php
// Update user other info
if (isset($_POST['update'])) {
  $req_fields = array('name', 'username');
  validate_fields($req_fields);
  if (empty($errors)) {
    $id = (int)$_SESSION['user_id'];
    $name = remove_junk($db->escape($_POST['name']));
    $username = remove_junk($db->escape($_POST['username']));
    $sql = "UPDATE users SET name ='{$name}', username ='{$username}' WHERE id='{$id}'";
    $result = $db->query($sql);
    if ($result && $db->affected_rows() === 1) {
      // Success
      echo "<script>
        Swal.fire({
          icon: 'success',
          title: 'Account updated!',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'edit_account.php';
          }
        });
      </script>";
    } else {
      // Failure
      echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Failed to update account!',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'edit_account.php';
          }
        });
      </script>";
    }
  } else {
    $session->msg("d", $errors);
    redirect('edit_account.php', false);
  }
}
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>

  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <span class="glyphicon glyphicon-camera"></span>
        <span>Change My photo</span>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-4">
            <img class="img-circle img-size-2" src="uploads/users/<?php echo $user['image']; ?>" alt="">
          </div>
          <div class="col-md-8">
            <form class="form" action="edit_account.php" method="POST" enctype="multipart/form-data">
              <div class="form-group">
                <label for="file_upload" class="control-label">Upload Files</label>
                <div class="btn btn-default btn-file">
                  <input type="file" name="file_upload" multiple="multiple" />
                </div>
              </div>
              <style>
                /* Style the file input button */
                .btn-file {
                  position: relative;
                  overflow: hidden;
                }

                /* Style the actual file input element */
                .btn-file input[type="file"] {
                  position: absolute;
                  top: 0;
                  right: 0;
                  min-width: 100%;
                  min-height: 100%;
                  font-size: 100px;
                  text-align: right;
                  filter: alpha(opacity=0);
                  opacity: 0;
                  outline: none;
                  background: white;
                  cursor: inherit;
                  display: block;
                }

                /* Add some styling when hovering over the file input button */
                .btn-file:hover {
                  background-color: #f5f5f5;
                }

                /* Add some padding to the file input button */
                .btn-file::before {
                  content: "Browse";
                  display: inline-block;
                  background: #428bca;
                  color: white;
                  padding: 6px 12px;
                  border-radius: 4px;
                  cursor: pointer;
                }

                /* Add styling when hovering over the "Browse" text */
                .btn-file:hover::before {
                  background: #357ebd;
                }
              </style>
              <div class="form-group">
                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                <button type="submit" name="submit" class="btn btn-warning">Change</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <span class="glyphicon glyphicon-edit"></span>
        <style>
          #openAlert {
            background-color: #364c6f;
            color: #fff;
            border: #687da3;
            padding: 10px 10px;
            font-size: 10px;
            cursor: pointer;
            border-radius: 5px;
          }
        </style>
        <span>Edit My Account <button id="openAlert"> <i class="glyphicon glyphicon-bell"></i></button> </span>
        <script>
  document.getElementById('openAlert').addEventListener('click', function() {
    Swal.fire({
      icon: 'info',
      title: 'Notice',
      text: 'Make sure that username and name will be same',
    });
  });
</script>
      </div>
      <div class="panel-body">
        <form method="post" action="edit_account.php?id=<?php echo (int)$user['id']; ?>" class="clearfix">
          <div class="form-group">
            <label for="name" class="control-label">Name</label>
            <input type="name" class="form-control" name="name" value="<?php echo remove_junk(ucwords($user['name'])); ?>">
          </div>
          <div class="form-group">
            <label for="username" class="control-label">Username</label>
            <input type="text" class="form-control" name="username" value="<?php echo remove_junk(ucwords($user['username'])); ?>">
          </div>
          <?php if ($user['user_level'] === '1'): ?>
            <div class="form-group clearfix">
              <a href="change_password.php" title="change password" class="btn btn-danger pull-right">Change Password <i class="fa fa-wrench" aria-hidden="true"></i></a>
            </div>
          <?php endif; ?>
          <div class="form-group">
            <button type="submit" name="update" class="btn btn-info">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<style>
  /* General styles */
  .img-circle.img-size-2 {
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }

  /* Mobile-specific styles */
  @media (max-width: 767px) {
    .col-md-6 {
      width: 100%;
    }

    .panel-heading.clearfix {
      padding-top: 10px;
      padding-bottom: 10px;
    }
  }
</style>

<?php include_once('layouts/footer.php'); ?>
