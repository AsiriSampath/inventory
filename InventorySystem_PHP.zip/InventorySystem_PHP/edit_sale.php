<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  $page_title = 'Edit sale';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(6);
?>
<?php
$sale = find_by_id('sales',(int)$_GET['id']);
if(!$sale){
  $session->msg("d","Missing product id.");
  redirect('sales.php');
}
?>
<?php $product = find_by_id('products',$sale['product_id']); ?>
<?php

  if(isset($_POST['update_sale'])){
    $req_fields = array('title', 'price','payment_method','delivery_ammount','delivery_method', 'quantity','discount_amount', 'description', 'total','customer_name', 'customer_email', 'customer_phone','address','place_by', 'date',);
      validate_fields($req_fields);
      if (empty($errors)) {
          $p_id      = $db->escape((int)$product['id']);
          $s_qty     = $db->escape((int)$_POST['quantity']);
          $s_payment_method   = $db->escape($_POST['payment_method']); 
          $s_discount_amount = $db->escape($_POST['discount_amount']);
          $s_description = $db->escape($_POST['description']);
          $s_total   = $db->escape($_POST['total']);
          $S_delivery_ammount   = $db->escape($_POST['delivery_ammount']);
          $s_delivery_method   = $db->escape($_POST['delivery_method']);
          $customer_name  = $db->escape($_POST['customer_name']);
          $customer_email = $db->escape($_POST['customer_email']);
          $customer_phone = $db->escape($_POST['customer_phone']);
          $s_address  = $db->escape($_POST['address']);
          $s_place  = $db->escape($_POST['place_by']);
          $date      = $db->escape($_POST['date']);
          $s_date    = date("Y-m-d", strtotime($date));

          $sql  = "UPDATE sales SET";
          $sql .= " product_id= '{$p_id}',qty={$s_qty},payment_method='{$s_payment_method}',price='{$s_total}',delivery_ammount='{$S_delivery_ammount}',delivery_method='{$s_delivery_method}',discount_amount='{$s_discount_amount}',description='{$s_description}', customer_name='{$customer_name}', customer_email='{$customer_email}', customer_phone='{$customer_phone}',date='{$s_date}', address='{$s_address}',place_by='{$s_place}'";
          $sql .= " WHERE id ='{$sale['id']}'";
          $result = $db->query($sql);
          if ($result && $db->affected_rows() === 1) {
            update_product_qty($s_qty, $p_id);
            // Success
            echo "<script>
              Swal.fire({
                icon: 'success',
                title: 'Sale updated!',
                showConfirmButton: false,
                timer: 1500,
                didClose: () =>) {
                  window.location.href = 'edit_sale.php?id=" . $sale['id'] . "';
                }
              });
            </script>";
          } else {
            // Failed
            echo "<script>
              Swal.fire({
                icon: 'error',
                title: 'Sorry, failed to update sale!',
                showConfirmButton: false,
                timer: 1500,
                didClose: () => {
                  window.location.href = 'sales.php';
                }
              });
            </script>";
          }
                
        } else {
           $session->msg("d", $errors);
           redirect('edit_sale.php?id='.(int)$sale['id'],false);
        }
  }

?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="container-fluid">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Sale Edit</span>
        </strong>
        <?php if ($user['user_level'] === '1' || $user['user_level'] === '2'): ?>
        <div class="pull-right">
          <a href="sales.php" class="btn btn-primary">Show all sales</a>
        </div>
        <?php endif; ?>
        </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Product title</th>
                <th>Qty</th>
                <th>Payment Method</th>
                <th>Price</th>
                <th>Delivery Amount</th>
                <th>Delivery Method</th>
                <th>Discount Amount</th>
                <th>Description</th>
                <th>Total</th>
                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Phone</th>
                <th>Address</th>
                <?php if ($user['user_level'] === '1'): ?>
                <th>SaleFor</th>
                <?php endif; ?>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="product_info">
              <tr>
                <form method="post" action="edit_sale.php?id=<?php echo (int)$sale['id']; ?>">
                  <td id="s_name">
                    <input type="text" class="form-control" id="sug_input" name="title" value="<?php echo remove_junk($product['name']); ?>">
                    <div id="result" class="list-group"></div>
                  </td>
                  <td id="s_qty">
                    <input type="text" class="form-control" name="quantity" value="<?php echo (int)$sale['qty']; ?>">
                  </td>
                  <td id="payment_method">
                    <select class="form-control" name="payment_method">
                      <option value="Cash" <?php if(remove_junk($sale['payment_method']) == "cash") echo "selected"; ?>>cash</option>
                      <option value="Credit Card" <?php if(remove_junk($sale['payment_method']) == "Credit Card") echo "selected"; ?>>Credit Card</option>
                      <option value="Bank Transfer" <?php if(remove_junk($sale['payment_method']) == "Bank Transfer") echo "selected"; ?>>Bank Transfer</option>
                    </select>
                  </td>
                  <td id="s_price">
                    <input type="text" class="form-control" name="price" value="<?php echo remove_junk($product['sale_price']); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="delivery_ammount" value="<?php echo remove_junk($sale['delivery_ammount']); ?>">
                  </td>
                  <td id="delivery_method">
                    <select class="form-control" name="delivery_method">
                      <option value="Cash" <?php if(remove_junk($sale['delivery_method']) == "cash") echo "selected"; ?>>cash</option>
                      <option value="COD" <?php if(remove_junk($sale['delivery_method']) == "COD") echo "selected"; ?>>COD</option>
                      <option value="Bank Transfer" <?php if(remove_junk($sale['delivery_method']) == "Bank Transfer") echo "selected"; ?>>Bank Transfer</option>
                    </select>
                  </td>
                    <td>
                      <input type="text" class="form-control" name="discount_amount" value="<?php echo remove_junk($sale['discount_amount']); ?>">
                    </td>
                    <td>
                      <textarea class="form-control" name="description" value="<?php echo remove_junk($sale['customer_name']); ?>"></textarea>
                    </td>
                    <td>
                    <input type="text" class="form-control" name="total" value="<?php echo remove_junk($sale['price']); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="customer_name" value="<?php echo remove_junk($sale['customer_name']); ?>">
                  </td>
                  <td>
                    <input type="email" class="form-control" name="customer_email" value="<?php echo remove_junk($sale['customer_email']); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="customer_phone" value="<?php echo remove_junk($sale['customer_phone']); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="address" value="<?php echo remove_junk($sale['address']); ?>">
                  </td>
                  <?php if ($user['user_level'] === '1'): ?>
                    <td id="place_by">
                        <select class="form-control" name="place_by">
                            <?php
                            $users = find_all_user();

                            // Create an associative array to group users by their group names
                            $userGroups = array();
                            foreach ($users as $user) {
                                $group = $user['group_name'];
                                if (!isset($userGroups[$group])) {
                                    $userGroups[$group] = array();
                                }
                                $userGroups[$group][] = $user;
                            }

                            // Loop through the user groups and populate the options
                            foreach ($userGroups as $group => $groupUsers) {
                                echo "<optgroup label=\"$group\">";
                                foreach ($groupUsers as $user) {
                                    $selected = (remove_junk($sale['place_by']) == $user['name']) ? "selected" : "";
                                    echo "<option value=\"" . $user['name'] . "\" $selected>" . $user['name'] . "</option>";
                                }
                                echo "</optgroup>";
                            }
                            ?>
                        </select>
                    </td>
                  <?php endif; ?>
                  <td id="s_date">
                    <input type="date" class="form-control datepicker" name="date" data-date-format="" value="<?php echo remove_junk($sale['date']); ?>">
                  </td>
                  <td>
                    <button type="submit" name="update_sale" class="btn btn-primary">Update sale</button>
                  </td>
                </form>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
