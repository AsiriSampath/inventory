<?php
  require_once('includes/load.php');

/*--------------------------------------------------------------*/
/* Function for find all database table rows by table name
/*--------------------------------------------------------------*/
function find_all($table) {
   global $db;
   if(tableExists($table))
   {
     return find_by_sql("SELECT * FROM ".$db->escape($table));
   }
}

/*--------------------------------------------------------------*/
/* Function for find all database table rows by table name
/*--------------------------------------------------------------*/
function find_all_u($table, $uid) {
  global $db;
  if (tableExists($table)) {
    return find_by_sql("SELECT * FROM " . $db->escape($table) . " WHERE m_user_id = " . (int)$uid);
  }
}
/*--------------------------------------------------------------*/
/* Function for find all database table rows by table name
/*--------------------------------------------------------------*/
function find_all_c($table, $uid) {
  global $db;
  if (tableExists($table)) {
    return find_by_sql("SELECT * FROM " . $db->escape($table) . " WHERE c_user_id = " . (int)$uid);
  }
}

/*--------------------------------------------------------------*/
/* Function for Perform queries
/*--------------------------------------------------------------*/
function find_by_sql($sql)
{
  global $db;
  $result = $db->query($sql);
  $result_set = $db->while_loop($result);
 return $result_set;
}
/*--------------------------------------------------------------*/
/*  Function for Find data from table by id
/*--------------------------------------------------------------*/
function find_by_id($table,$id)
{
  global $db;
  $id = (int)$id;
    if(tableExists($table)){
          $sql = $db->query("SELECT * FROM {$db->escape($table)} WHERE id='{$db->escape($id)}' LIMIT 1");
          if($result = $db->fetch_assoc($sql))
            return $result;
          else
            return null;
     }
}
/*--------------------------------------------------------------*/
/* Function for Delete data from table by id
/*--------------------------------------------------------------*/
function delete_by_id($table,$id)
{
  global $db;
  if(tableExists($table))
   {
    $sql = "DELETE FROM ".$db->escape($table);
    $sql .= " WHERE id=". $db->escape($id);
    $sql .= " LIMIT 1";
    $db->query($sql);
    return ($db->affected_rows() === 1) ? true : false;
   }
}
/*--------------------------------------------------------------*/
/* Function for Count id  By table name
/*--------------------------------------------------------------*/

function count_by_id($table){
  global $db;
  if(tableExists($table))
  {
    $sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
    $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
}

/*--------------------------------------------------------------*/
/* Determine if database table exists
/*--------------------------------------------------------------*/
function tableExists($table){
  global $db;
  $table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
      if($table_exit) {
        if($db->num_rows($table_exit) > 0)
              return true;
         else
              return false;
      }
  }
 /*--------------------------------------------------------------*/
 /* Login with the data provided in $_POST,
 /* coming from the login form.
/*--------------------------------------------------------------*/
function authenticate($username='', $password='') {
  global $db;
  $username = $db->escape($username);
  $password = $db->escape($password);
  $sql = sprintf("SELECT users.id AS id,username,name,password,user_level,group_name FROM users,user_groups WHERE users.user_level=user_groups.group_level AND username ='%s' LIMIT 1", $username);
  $result = $db->query($sql);
  if ($db->num_rows($result)) {
      $user = $db->fetch_assoc($result);
      $password_request = sha1($password);
      if ($password_request === $user['password']) {
          return $user; // Return the complete user data array
      }
  }
  return false;
}

  /*--------------------------------------------------------------*/
  /* Login with the data provided in $_POST,
  /* coming from the login_v2.php form.
  /* If you used this method then remove authenticate function.
 /*--------------------------------------------------------------*/
function authenticate_v2($username='', $password='') {
    global $db;
    $username = $db->escape($username);
    $password = $db->escape($password);
    $sql = sprintf("SELECT users.id AS id,username,name,password,user_level,group_name FROM users,user_groups WHERE users.user_level=user_groups.group_level AND username ='%s' LIMIT 1", $username);
    $result = $db->query($sql);
    if ($db->num_rows($result)) {
        $user = $db->fetch_assoc($result);
        $password_request = sha1($password);

        // Instead of checking if the passwords match, we'll just return the user
        return $user;
    }
    return false;
}
  /*--------------------------------------------------------------*/
  /* Find current log in user by session id
  /*--------------------------------------------------------------*/
  function current_user(){
      static $current_user;
      global $db;
      if(!$current_user){
         if(isset($_SESSION['user_id'])):
             $user_id = intval($_SESSION['user_id']);
             $current_user = find_by_id('users',$user_id);
        endif;
      }
    return $current_user;
  }
  /*--------------------------------------------------------------*/
  /* Find all user by
  /* Joining users table and user gropus table
  /*--------------------------------------------------------------*/
  function find_all_user(){
      global $db;
      $results = array();
      $sql = "SELECT u.id, u.name, u.username, u.email, u.phone_no, u.user_level, u.status, u.last_login, image, ";
      $sql .= "g.group_name ";
      $sql .= "FROM users u ";
      $sql .= "LEFT JOIN user_groups g ";
      $sql .= "ON g.group_level = u.user_level ";
      $sql .= "ORDER BY u.name ASC";
      $result = find_by_sql($sql);
      return $result;
  }
  /*--------------------------------------------------------------*/
  /* Find all sellers by
  /* Joining sellers table and sellers gropus table
  /*--------------------------------------------------------------*/
  function find_all_sellers() {
    global $db;
    $results = array();
    $sql = "SELECT u.id, u.name ";
    $sql .= "FROM users u ";
    $sql .= "LEFT JOIN user_groups g ";
    $sql .= "ON g.group_level = u.user_level ";
    $sql .= "WHERE g.group_name = 'Seller' "; 
    $sql .= "ORDER BY u.name ASC";
    $result = find_by_sql($sql);
    return $result;
  }  
  /*--------------------------------------------------------------*/
 /* Function for find all seller report date by date 
 /*--------------------------------------------------------------*/
 function generate_seller_sales_report($seller_id, $start_date, $end_date) {
  global $db;

  if ($seller_id === 'all') {
      // Generate report for all sellers within the specified date range
      $sql = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_ammount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
      $sql .= "COUNT(s.product_id) AS total_records, ";
      $sql .= "SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "u.name AS seller_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}' AND '{$seller_id}' ";
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";

      return $db->query($sql);
  } else {
      // Generate report for the selected seller within the specified date range
      $sql = "SELECT s.id, SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by, user_id, s.place_by, ";
      $sql .= "p.sale_price, p.buy_price, ";
      $sql .= "u.name AS seller_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE u.id = '{$seller_id}' AND s.date >= '{$start_date}' AND s.date <= '{$end_date}' ";
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";

      return $db->query($sql);
  }
}
  /*--------------------------------------------------------------*/
  /* Find all staff by
  /* Joining staff table and staff gropus table
  /*--------------------------------------------------------------*/
  function find_all_staff() {
    global $db;
    $results = array();
    $sql = "SELECT u.id, u.name ";
    $sql .= "FROM users u ";
    $sql .= "LEFT JOIN user_groups g ";
    $sql .= "ON g.group_level = u.user_level ";
    $sql .= "WHERE g.group_name = 'staff' "; 
    $sql .= "ORDER BY u.name ASC";
    $result = find_by_sql($sql);
    return $result;
}
  /*--------------------------------------------------------------*/
 /* Function for find all staff report date by date 
 /*--------------------------------------------------------------*/
 function generate_staff_sales_report($staff_id, $start_date, $end_date) {
  global $db;

  if ($staff_id === 'all') {
      // Generate report for all staff members within the specified date range
      $sql = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_ammount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
      $sql .= "COUNT(s.product_id) AS total_records, ";
      $sql .= "SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "u.name AS staff_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}' AND '{$staff_id}' ";
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";

      return $db->query($sql);
  } else {
      // Generate report for the selected staff member within the specified date range
      $sql = "SELECT s.id, SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by, user_id, s.place_by, ";
      $sql .= "p.sale_price, p.buy_price, ";
      $sql .= "u.name AS staff_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE u.id = '{$staff_id}' AND s.date >= '{$start_date}' AND s.date <= '{$end_date}' ";
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";

      return $db->query($sql);
  }
}

  /*--------------------------------------------------------------*/
  /* Find all Partners by
  /* Joining Partners table and Partners gropus table
  /*--------------------------------------------------------------*/
  function find_all_partner() {
    global $db;
    $results = array();
    $sql = "SELECT u.id, u.name ";
    $sql .= "FROM users u ";
    $sql .= "LEFT JOIN user_groups g ";
    $sql .= "ON g.group_level = u.user_level ";
    $sql .= "WHERE g.group_name = 'partner' "; 
    $sql .= "ORDER BY u.name ASC";
    $result = find_by_sql($sql);
    return $result;
  }  

/*--------------------------------------------------------------*/
 /* Function for find all partner report date by date 
 /*--------------------------------------------------------------*/
  function generate_partner_sales_report($partner_id, $start_date, $end_date) {
    global $db;

    if ($partner_id === 'all') {
        // Generate report for all partners within the specified date range
        $sql = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_amount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
        $sql .= "COUNT(s.product_id) AS total_records, ";
        $sql .= "SUM(s.qty) AS total_sales, ";
        $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
        $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
        $sql .= "u.name AS partner_name ";
        $sql .= "FROM sales s ";
        $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
        $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
        $sql .= "WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}' AND '{$partner_id}' ";
        $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
        $sql .= "ORDER BY DATE(s.date) DESC";

        return $db->query($sql);
    } else {
        // Generate report for the selected partner within the specified date range
        $sql = "SELECT s.id, SUM(s.qty) AS total_sales, ";
        $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
        $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
        $sql .= "s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by, user_id, s.place_by, ";
        $sql .= "p.sale_price, p.buy_price, ";
        $sql .= "u.name AS partner_name ";
        $sql .= "FROM sales s ";
        $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
        $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
        $sql .= "WHERE u.id = '{$partner_id}' AND s.date >= '{$start_date}' AND s.date <= '{$end_date}' ";
        $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
        $sql .= "ORDER BY DATE(s.date) DESC";

        return $db->query($sql);
    }
}

  /*--------------------------------------------------------------*/
  /* Find all drivers by
  /* Joining drivers table and drivers gropus table
  /*--------------------------------------------------------------*/
  function find_all_delivery_drivers() {
    global $db;
    $results = array();
    $sql = "SELECT u.id, u.name ";
    $sql .= "FROM users u ";
    $sql .= "LEFT JOIN user_groups g ";
    $sql .= "ON g.group_level = u.user_level ";
    $sql .= "WHERE g.group_name = 'delivery drivers' "; 
    $sql .= "ORDER BY u.name ASC";
    $result = find_by_sql($sql);
    return $result;
  }  
/*--------------------------------------------------------------*/
 /* Function for find all drivers report date by date 
 /*--------------------------------------------------------------*/
 function generate_drivers_report($drivers_id, $start_date, $end_date) {
  global $db;

  if ($drivers_id === 'all') {
      // Generate report for all drivers within the specified date range
      $sql = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_ammount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
      $sql .= "COUNT(s.product_id) AS total_records, ";
      $sql .= "SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "u.name AS driver_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}' ";
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";
      $results = $db->query($sql);
      
      // Filter results for COD delivery method
      $results = array_filter($results, function($result) {
          return remove_junk($result['delivery_method']) === 'COD';
      });

      return $results;
  } else {
      // Generate report for the selected driver within the specified date range
      $sql = "SELECT s.id, SUM(s.qty) AS total_sales, ";
      $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
      $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price, ";
      $sql .= "s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by, user_id, s.place_by, ";
      $sql .= "p.sale_price, p.buy_price, ";
      $sql .= "u.name AS driver_name ";
      $sql .= "FROM sales s ";
      $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
      $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
      $sql .= "WHERE u.id = '{$drivers_id}' AND s.date BETWEEN '{$start_date}' AND '{$end_date}' ";
      $sql .= "AND s.delivery_method = 'COD' "; // Only COD delivery method
      $sql .= "GROUP BY s.id, DATE(s.date), p.name, u.name ";
      $sql .= "ORDER BY DATE(s.date) DESC";
      $results = $db->query($sql);
      
      // Filter results for COD delivery method
      return $results;
  }
}


  /*--------------------------------------------------------------*/
  /* Function to update the last log in of a user
  /*--------------------------------------------------------------*/

 function updateLastLogIn($user_id)
	{
		global $db;
    date_default_timezone_set('Asia/Colombo');
    $date = make_date();
    $sql = "UPDATE users SET last_login='{$date}' WHERE id ='{$user_id}' LIMIT 1";
    $result = $db->query($sql);
    return ($result && $db->affected_rows() === 1 ? true : false);
	}
  {
      return date('Y-m-d H:i:s', time());
  }
  /*--------------------------------------------------------------*/
  /* Find all Group name
  /*--------------------------------------------------------------*/
  function find_by_groupName($val)
  {
    global $db;
    $sql = "SELECT group_name FROM user_groups WHERE group_name = '{$db->escape($val)}' LIMIT 1 ";
    $result = $db->query($sql);
    return($db->num_rows($result) === 0 ? true : false);
  }
  /*--------------------------------------------------------------*/
  /* Find group level
  /*--------------------------------------------------------------*/
  function find_by_groupLevel($level)
  {
    global $db;
    $sql = "SELECT group_level FROM user_groups WHERE group_level = '{$db->escape($level)}' LIMIT 1 ";
    $result = $db->query($sql);
    return($db->num_rows($result) === 0 ? true : false);
  }
  /*--------------------------------------------------------------*/
  /* Function for cheaking which user level has access to page
  /*--------------------------------------------------------------*/
   function page_require_level($require_level){
     global $session;
     $current_user = current_user();
     $login_level = find_by_groupLevel($current_user['user_level']);
     //if user not login
     if (!$session->isUserLoggedIn(true)):
            $session->msg('d','Please login...');
            redirect('index.php', false);
      //if Group status Deactive
     elseif($login_level['group_status'] === '1'):
           $session->msg('d','This level user has been band!');
           redirect('home.php',false);
      //cheackin log in User level and Require level is Less than or equal to
     elseif($current_user['user_level'] <= (int)$require_level):
              return true;
      else:
            $session->msg("d", "Sorry! you dont have permission to view the page.");
            redirect('home.php', false);
        endif;

     }
   /*--------------------------------------------------------------*/
   /* Function for Finding all product name
   /* JOIN with categorie  and media database table
   /*--------------------------------------------------------------*/
   function join_product_table()
   {
     global $db;
     $sql = "SELECT p.id,p.name,p.quantity,p.buy_price,p.sale_price,p.date,p.media_id,p.categorie_id,p.updated_at,p.p_user_id,";
     $sql .= "c.name AS categorie, m.file_name AS image, u.username AS place_by ";
     $sql .= "FROM products p ";
     $sql .= "LEFT JOIN categories c ON c.id = p.categorie_id ";
     $sql .= "LEFT JOIN media m ON m.id = p.media_id ";
     $sql .= "LEFT JOIN users u ON u.id = p.p_user_id ";
     $sql .= "ORDER BY p.id ASC";
     return find_by_sql($sql);
   }
   
   /*--------------------------------------------------------------*/
   /* Function for Finding all product name by user
   /* JOIN with categorie  and media database table
   /*--------------------------------------------------------------*/

   function join_product_table_u($uid)
   {
     global $db;
     $sql = "SELECT p.id,p.name,p.quantity,p.buy_price,p.sale_price,p.date,p.media_id,p.categorie_id,p.updated_at,p.p_user_id,";
     $sql .= "c.name AS categorie, m.file_name AS image ";
     $sql .= "FROM products p ";
     $sql .= "LEFT JOIN categories c ON c.id = p.categorie_id ";
     $sql .= "LEFT JOIN media m ON m.id = p.media_id ";
     $sql .= " WHERE p.p_user_id = '$uid'"; 
     $sql .= "ORDER BY p.id ASC";
     return find_by_sql($sql);
   }
   /*--------------------------------------------------------------*/
   /* Function for get_user_sold_products
   /*--------------------------------------------------------------*/
   function get_user_sold_products($username) {
    global $db;
    $sql = "SELECT p.name AS product_name, SUM(s.qty) AS total_sold
            FROM sales s
            LEFT JOIN products p ON s.product_id = p.id
            LEFT JOIN users u ON s.place_by  = u.username
            WHERE u.username = '$username'
            GROUP BY p.id, p.name
            ORDER BY p.name ASC";
    return find_by_sql($sql);
  }
  

  /*--------------------------------------------------------------*/
  /* Function for Finding all product name
  /* Request coming from ajax.php for auto suggest
  /*--------------------------------------------------------------*/

   function find_product_by_title($product_name){
     global $db;
     $p_name = remove_junk($db->escape($product_name));
     $sql = "SELECT name FROM products WHERE name like '%$p_name%' LIMIT 5";
     $result = find_by_sql($sql);
     return $result;
   }

  /*--------------------------------------------------------------*/
  /* Function for Finding all product info by product title
  /* Request coming from ajax.php
  /*--------------------------------------------------------------*/
  function find_all_product_info_by_title($title){
    global $db;
    $sql  = "SELECT * FROM products ";
    $sql .= " WHERE name ='{$title}'";
    $sql .=" LIMIT 1";
    return find_by_sql($sql);
  }

  /*--------------------------------------------------------------*/
  /* Function for Update product quantity
  /*--------------------------------------------------------------*/
  function update_product_qty($qty,$p_id){
    global $db;
    $qty = (int) $qty;
    $id  = (int)$p_id;
    $sql = "UPDATE products SET quantity=quantity -'{$qty}' WHERE id = '{$id}'";
    $result = $db->query($sql);
    return($db->affected_rows() === 1 ? true : false);

  }
  /*--------------------------------------------------------------*/
  /* Function for Display Recent product Added
  /*--------------------------------------------------------------*/
 function find_recent_product_added($limit){
   global $db;
   $sql   = " SELECT p.id,p.name,p.sale_price,p.media_id,c.name AS categorie,";
   $sql  .= " m.file_name AS image FROM products p";
   $sql  .= " LEFT JOIN categories c ON c.id = p.categorie_id";
   $sql  .= " LEFT JOIN media m ON m.id = p.media_id";
   $sql  .= " ORDER BY p.id DESC LIMIT ".$db->escape((int)$limit);
   return find_by_sql($sql);
 }
 /*--------------------------------------------------------------*/
 /* Function for Find Highest saleing Product
 /*--------------------------------------------------------------*/
 function find_higest_saleing_product($limit){
   global $db;
   $sql  = "SELECT p.name, COUNT(s.product_id) AS totalSold, SUM(s.qty) AS totalQty";
   $sql .= " FROM sales s";
   $sql .= " LEFT JOIN products p ON p.id = s.product_id ";
   $sql .= " GROUP BY s.product_id";
   $sql .= " ORDER BY SUM(s.qty) DESC LIMIT ".$db->escape((int)$limit);
   return $db->query($sql);
 }
  /*--------------------------------------------------------------*/
  /* Function for Display Recent product Added by user
  /*--------------------------------------------------------------*/
  function find_recent_product_added_by_uid($uid, $limit) {
    global $db;
    $sql   = "SELECT p.id,p.name,p.sale_price,p.media_id,c.name AS categorie,p.p_user_id,";
    $sql  .= " m.file_name AS image FROM products p";
    $sql  .= " LEFT JOIN categories c ON c.id = p.categorie_id";
    $sql  .= " LEFT JOIN media m ON m.id = p.media_id";
    $sql  .= " WHERE p.p_user_id = '" . $db->escape($uid) . "'";
    $sql  .= " ORDER BY p.id DESC LIMIT " . $db->escape((int)$limit);
    return find_by_sql($sql);
}  
 /*--------------------------------------------------------------*/
 /* Function for Find Highest saleing Product by user
 /*--------------------------------------------------------------*/
 function find_highest_selling_product_u($username, $limit) {
  global $db;
  $sql  = "SELECT p.name, COUNT(s.product_id) AS totalSold, SUM(s.qty) AS totalQty";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON p.id = s.product_id";
  $sql .= " WHERE s.place_by = '" . $db->escape($username) . "'";
  $sql .= " GROUP BY s.product_id";
  $sql .= " ORDER BY SUM(s.qty) DESC LIMIT " . $db->escape((int)$limit);
  return $db->query($sql);
}

 /*--------------------------------------------------------------*/
 /* Function for find all sales
 /*--------------------------------------------------------------*/
 function find_all_sale(){
  global $db;
  $sql  = "SELECT s.id, s.qty, s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name,s.address,s.added_by,s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by,user_id,place_by";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " LEFT JOIN users u ON s.added_by = u.username";
  $sql .= " ORDER BY s.date DESC";
  return find_by_sql($sql);
}
 
/*--------------------------------------------------------------*/
/* Function for find all customer details from sales table
/*--------------------------------------------------------------*/
function find_all_customer_details(){
  global $db;
  $sql  = "SELECT s.customer_name, s.customer_email, s.customer_phone,s.address,s.date";
  $sql .= " FROM sales s";
  $sql .= " ORDER BY s.date DESC";
  return find_by_sql($sql);
}
 /*--------------------------------------------------------------*/
 /* Function for find all sales uid
 /*--------------------------------------------------------------*/
 function find_all_sale_u($username) {
  global $db;
  $sql  = "SELECT s.id, s.qty, s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.id AS user_id ";
  $sql .= "FROM sales s ";
  $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
  $sql .= "LEFT JOIN users u ON s.place_by = u.username ";
  $sql .= "WHERE u.username = '$username' ";
  $sql .= "ORDER BY s.date DESC";
  return find_by_sql($sql);
}

 /*--------------------------------------------------------------*/
 /* Function for Display Recent sale
 /*--------------------------------------------------------------*/
function find_recent_sale_added($limit){
  global $db;
  $sql  = "SELECT s.id,s.qty,s.price,s.date,p.name";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " ORDER BY s.date DESC LIMIT ".$db->escape((int)$limit);
  return find_by_sql($sql);
}
 /*--------------------------------------------------------------*/
 /* Function for Display Recent sale
 /*--------------------------------------------------------------*/
 function find_recent_sale_added_u($username, $limit) {
  global $db;
  $sql  = "SELECT s.id, s.qty, s.price, s.date, p.name";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " WHERE s.place_by = '" . $db->escape($username) . "'";
  $sql .= " ORDER BY s.date DESC LIMIT " . $db->escape((int)$limit);
  return find_by_sql($sql);
}

/*--------------------------------------------------------------*/
/* Function for Generate sales report by two dates
/*--------------------------------------------------------------*/
function find_all_sales($start_date, $end_date) {
  global $db;
  $sql  = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_ammount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
  $sql .= "COUNT(s.product_id) AS total_records, ";
  $sql .= "SUM(s.qty) AS total_sales, ";
  $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price, ";
  $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price ";
  $sql .= "FROM sales s ";
  $sql .= "LEFT JOIN products p ON s.product_id = p.id ";
  $sql .= "WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}' ";
  $sql .= "GROUP BY s.id, DATE(s.date), p.name ";
  $sql .= "ORDER BY DATE(s.date) DESC";
  return $db->query($sql);
}

/*--------------------------------------------------------------*/
/* Function for Generate sales report by two dates by uid
/*--------------------------------------------------------------*/
function find_sale_by_dates_u($start_date, $end_date, $username) {
  global $db;
  $start_date = date("Y-m-d", strtotime($start_date));
  $end_date = date("Y-m-d", strtotime($end_date));
  $sql  = "SELECT s.id, s.date, p.name, p.sale_price, p.buy_price, payment_method, delivery_ammount, delivery_method, customer_name, s.customer_email, s.customer_phone, s.address, ";
  $sql .= " COUNT(s.product_id) AS total_records,";
  $sql .= " SUM(s.qty) AS total_sales,";
  $sql .= " SUM(p.sale_price * s.qty) AS total_saleing_price,";
  $sql .= " SUM(p.buy_price * s.qty) AS total_buying_price ";
  $sql .= " FROM sales s ";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " LEFT JOIN users u ON s.place_by = u.username";
  $sql .= " WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}'";
  $sql .= " AND u.username = '{$username}'";
  $sql .= " GROUP BY DATE(s.date), p.name";
  $sql .= " ORDER BY DATE(s.date) DESC";
  return $db->query($sql);
}

/*----------------------------------------------------------------*/
/*function for generate sales report according to product*/
/*------------------------------------------------------------------*/
function find_sale_by_dates_product($start_date,$end_date,$product){
  global $db;
  $start_date  = date("Y-m-d", strtotime($start_date));
  $end_date    = date("Y-m-d", strtotime($end_date));
     $p_name = remove_junk($db->escape($product));

  $sql  = "SELECT s.date, p.name,p.sale_price,p.buy_price,";
  $sql .= "COUNT(s.product_id) AS total_records,";
  $sql .= "SUM(s.qty) AS total_sales,";
  $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price,";
  $sql .= "SUM(p.buy_price * s.qty) AS total_buying_price ";
  $sql .= "FROM sales s ";
  $sql .= "LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " WHERE s.date BETWEEN '{$start_date}' AND '{$end_date}'";
  $sql .= "AND p.name='$p_name'";
  $sql .= " GROUP BY DATE(s.date)";
  $sql .= " ORDER BY DATE(s.date) DESC";
  return $db->query($sql);
}
/*--------------------------------------------------------------*/
/* Function for Generate Daily sales report
/*--------------------------------------------------------------*/

function dailySales($year, $month) {
  global $db;
  $sql  = "SELECT s.qty,";
  $sql .= " DATE_FORMAT(s.date, '%Y-%m-%e') AS date, p.name,";
  $sql .= " SUM(s.qty) AS total_qty,";
  $sql .= " SUM(p.sale_price * s.qty) AS total_saleing_price";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m' ) = '{$year}-{$month}'";
  $sql .= " GROUP BY s.date, s.product_id";
  return find_by_sql($sql);
}
/*--------------------------------------------------------------*/
/* Function for Generate Daily sales u report
/*--------------------------------------------------------------*/

function dailySales_u($username, $year, $month) {
  global $db;
  $sql  = "SELECT s.qty,";
  $sql .= " DATE_FORMAT(s.date, '%Y-%m-%e') AS date, p.name,";
  $sql .= " SUM(s.qty) AS total_qty,";
  $sql .= " SUM(p.sale_price * s.qty) AS total_saleing_price";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " LEFT JOIN users u ON s.place_by = u.username";
  $sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m' ) = '{$year}-{$month}'";
  $sql .= " AND u.username = '$username'";
  $sql .= " GROUP BY s.date, s.product_id";
  return find_by_sql($sql);
}

/*--------------------------------------------------------------*/
/* Function for Generate Monthly sales report
/*--------------------------------------------------------------*/
function  monthlySales($year,$month,$date){
  global $db;
  $sql  = "SELECT s.qty,";
  $sql .= " DATE_FORMAT(s.date, '%Y-%m-%d') AS date,p.name,";
  $sql .= " SUM(s.qty) AS total_qty,";
  $sql .= "SUM(p.sale_price * s.qty) AS total_saleing_price";
  $sql .= " FROM sales s";
  $sql .= " LEFT JOIN products p ON s.product_id = p.id";
  $sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m-%d' ) = '{$year}-{$month}-{$date}'";
  $sql .= " GROUP BY DATE_FORMAT( s.date,  '%d' ),s.product_id";
  $sql .= " ORDER BY date_format(s.date, '%d' ) ASC";
  return find_by_sql($sql);
}
/*--------------------------------------------------------------*/
/* Function for Generate Monthly sales u report
/*--------------------------------------------------------------*/
function monthlySales_u($username, $year, $month, $date) {
    global $db;
    $sql  = "SELECT s.qty,";
    $sql .= " DATE_FORMAT(s.date, '%Y-%m-%d') AS date, p.name,";
    $sql .= " SUM(s.qty) AS total_qty,";
    $sql .= " SUM(p.sale_price * s.qty) AS total_saleing_price";
    $sql .= " FROM sales s";
    $sql .= " LEFT JOIN products p ON s.product_id = p.id";
    $sql .= " LEFT JOIN users u ON s.place_by = u.username";
    $sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m-%d' ) = '{$year}-{$month}-{$date}'";
    $sql .= " AND u.username = '$username'";
    $sql .= " GROUP BY DATE_FORMAT( s.date, '%d' ), s.product_id";
    $sql .= " ORDER BY DATE_FORMAT(s.date, '%d' ) ASC";
    return find_by_sql($sql);
}


