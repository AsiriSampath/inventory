<?php
  ob_start();
  require_once('includes/load.php');
  if($session->isUserLoggedIn(true)) { redirect('home.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<div class="login-page">
    <div class="text-center">
       <h1>Welcome</h1>
       <p>Sign in to start your session</p>
     </div>
     <?php echo display_msg($msg); ?>
      <form method="post" action="auth.php" class="clearfix">
        <div class="form-group">
              <label for="username" class="control-label">Username</label>
              <input type="text" class="form-control" name="username" placeholder="Username">
        </div>
        <div class="form-group">
            <label for="Password" class="control-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Password">
        </div>
        <div class="form-group">
                <button type="submit" class="btn btn-info pull-right">Login</button>
        </div>
    </form>
</div>
      <style>
  body {
    background-color: #f2f2f2;
    font-family: Arial, sans-serif;
  }

  .login-page {
    max-width: 400px;
    margin: 0 auto;
    padding: 40px 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .login-page .text-center {
    margin-bottom: 30px;
  }

  .login-page h1 {
    font-size: 24px;
    margin-bottom: 10px;
    color: #333;
  }

  .login-page h4 {
    font-size: 14px;
    color: #777;
  }

  .login-page form {
    margin-top: 30px;
  }

  .login-page .form-group {
    margin-bottom: 20px;
  }

  .login-page label {
    font-weight: bold;
  }

  .login-page .form-control {
    width: 100%;
    height: 40px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  }

  .login-page .form-control:focus {
    border-color: #66afe9;
    outline: 0;
    box-shadow: 0 0 8px rgba(102, 175, 233, 0.6);
  }

  .login-page .btn {
    border-radius: 0;
  }
      </style>
    </div>
  </form>
</div>
<?php include_once('layouts/footer.php'); ?>
