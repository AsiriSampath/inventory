-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2023 at 07:33 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `c_user_id` varchar(150) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `c_user_id`, `status`, `created_at`) VALUES
(90, 'Demo category 1', '', 'pending', '2023-08-08 10:29:16'),
(91, 'demo category 2', '', 'pending', '2023-08-08 10:29:25'),
(92, 'demo category 3', '', 'pending', '2023-08-08 10:29:32'),
(93, 'demo category 4', '', 'pending', '2023-08-08 10:29:40'),
(94, 'demo category 5', '', 'pending', '2023-08-08 10:29:48');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) UNSIGNED NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  `m_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `file_name`, `file_type`, `m_user_id`) VALUES
(43, 'images.png', 'image/png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `buy_price` decimal(25,2) DEFAULT NULL,
  `sale_price` decimal(25,2) NOT NULL,
  `categorie_id` int(11) UNSIGNED NOT NULL,
  `media_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `p_user_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `buy_price`, `sale_price`, `categorie_id`, `media_id`, `date`, `updated_at`, `p_user_id`) VALUES
(93, 'product 1', '2', 1000.00, 2000.00, 90, 43, '2023-08-08 16:00:39', '2023-08-08 16:10:16', 582),
(94, 'product 2', '5', 2000.00, 3000.00, 91, 43, '2023-08-08 16:01:00', '2023-08-08 16:10:26', 582),
(95, 'product 3', '7', 3000.00, 4000.00, 92, 43, '2023-08-08 16:01:18', '2023-08-08 16:10:36', 582),
(96, 'product 4', '8', 4000.00, 5000.00, 93, 43, '2023-08-08 16:01:38', '2023-08-08 16:10:52', 582),
(97, 'product 5', '6', 5000.00, 6000.00, 94, 43, '2023-08-08 16:02:07', '2023-08-08 16:11:06', 582);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `request_title` varchar(255) NOT NULL,
  `request_description` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `date` date NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_phone` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `added_by` varchar(50) NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `payment_method` varchar(150) NOT NULL,
  `delivery_ammount` int(50) DEFAULT NULL,
  `delivery_method` varchar(50) NOT NULL,
  `discount_amount` int(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `user_id` varchar(150) NOT NULL,
  `place_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `qty`, `price`, `date`, `customer_email`, `customer_phone`, `customer_name`, `address`, `added_by`, `updated_by`, `payment_method`, `delivery_ammount`, `delivery_method`, `discount_amount`, `description`, `user_id`, `place_by`) VALUES
(331, 93, 1, 2000.00, '2023-08-08', 'customer@gmail.com', 123123123, 'customer1', 'cusomeradrress', 'admin', '', 'cash', 0, 'cash', 0, '', '582', 'partner'),
(332, 94, 1, 3000.00, '2023-08-08', 'customer@gmail.com', 123123213, 'customer2', 'cusomeradrress', 'admin', '', 'credit_card', 0, 'credit_card', 0, '', '582', 'seller'),
(333, 95, 2, 7800.00, '2023-08-08', 'customer@gmail.com', 123123123, 'customer3', 'cusomeradrress', 'admin', '', 'bank_transfer', 0, 'bank_transfer', 200, 'description', '582', 'staff'),
(334, 96, 1, 5500.00, '2023-08-08', 'customer@gmail.com', 123123213, 'customer4', 'cusomeradrress', 'admin', '', 'cash', 500, 'cash', 0, '', '582', 'partner'),
(335, 97, 1, 6100.00, '2023-08-08', 'customer@gmail.com', 123123213, 'customer5', 'cusomeradrress', 'admin', '', 'credit_card', 200, 'bank_transfer', 100, 'description', '582', 'seller'),
(336, 93, 1, 2000.00, '2023-08-08', 'customer@gmail.com', 123123123, 'customer1', 'cusomeradrress', 'admin', '', 'cash', 0, 'cash', 0, '', '582', 'staff'),
(338, 93, 1, 2000.00, '2023-08-09', 'as@gmail.com', 1212213, 'as', 'asddasasd', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'partner'),
(339, 93, 2, 4000.00, '2023-08-09', 'asas@gmail.com', 1231244, 'as', 'asasDA', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'partner'),
(340, 93, 1, 2000.00, '2023-08-09', 'dsada@gmail.com', 12312, 'asd', 'dvadfda', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'seller'),
(341, 95, 1, 4000.00, '2023-08-09', 'asd@dfa.vcom', 1231231, 'asdas', 'asdasfaf', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', '582'),
(342, 96, 1, 5000.00, '2023-08-09', 'sadas@gdg.cyu', 134123, 'sadasda', 'asdasda', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', '590'),
(343, 97, 1, 6000.00, '2023-08-09', 'asfasd@afaf.ch', 123214, 'afdsfs', 'asasd', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', '585'),
(344, 94, 1, 3000.00, '2023-08-09', 'asdasd@hgh.fs', 1231, 'adasda', 'asdasd', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'adasd'),
(345, 93, 1, 2000.00, '2023-08-09', 'asda@hgh.sds', 123124, 'asdasdassa', 'asda', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'staff'),
(346, 97, 2, 13000.00, '2023-08-09', 'sam@gmail.com', 891234134, 'sam', 'nokh', 'Admin', '', 'cash', 1000, 'cash', 0, '', '582', 'seller'),
(347, 93, 1, 2000.00, '2023-08-10', 'kkk@kk.kk', 1212121212, 'kkkkk', 'kkkkkk', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'seller'),
(348, 94, 1, 3000.00, '2023-08-10', 'aaa@aa.aa', 121313, 'aaaa', 'aaaa', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'adasd'),
(349, 94, 1, 3000.00, '2023-08-10', 'ddd@dd.dd', 121212, 'ddd', 'dddd', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'staff'),
(350, 94, 1, 3000.00, '2023-08-10', 'fff@ff.ff', 12143124, 'fff', 'ffff', 'Admin', '', 'cash', 0, 'cash', 0, '', '582', 'seller');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `email` text NOT NULL,
  `phone_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `image`, `status`, `last_login`, `email`, `phone_no`) VALUES
(582, 'admin', 'admin', 'admin', 1, 'poy8msr2582.jpeg', 1, '2023-08-10 21:53:05', 'admin@.com', 12323123),
(584, 'manager', 'manager', '1a8565a9dc72048ba03b4156be3e569f22771f23', 2, 'no_image.jpg', 1, '2023-08-08 16:42:55', 'manager@gmail.com', 1232313123),
(585, 'staff', 'staff', '9e89849ed241f45d7a189cfdaa633af36077ff69', 3, 'no_image.jpg', 1, '2023-08-08 17:00:55', 'staff@gmail.com', 123213213),
(586, 'seller', 'seller', '2e7464a5e9bac192f1251866fea0c255db0cbd83', 4, 'no_image.jpg', 1, '2023-08-08 17:01:34', 'seller@gmail.com', 12323112),
(587, 'partner', 'partner', '3624db883007efa198232b3aa774a54360ed3f26', 5, 'no_image.jpg', 1, '2023-08-08 17:02:16', 'partner@gmail.com', 12323123),
(588, 'driver', 'driver', 'fdda0c46f953c1a45bdc520849be1e4edf4e228c', 6, 'no_image.jpg', 1, NULL, 'driver@gmail.com', 12332123),
(589, 'adasd', 'asdassda', '63b4bacc828939706ea2a84822a4505efa73ee3e', 4, 'no_image.jpg', 1, NULL, 'asdasd@wqw.com', 1231244),
(590, 'asdasd', 'asdasdsa', 'a502ce1eff5696a67621d6368cfca455fc3648f9', 3, 'no_image.jpg', 1, NULL, 'asdsad@gsdf.com', 1232131);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(87, 'Admin', 1, 1),
(88, 'manager', 2, 1),
(89, 'staff', 3, 1),
(90, 'seller', 4, 1),
(91, 'partner', 5, 1),
(92, 'Delivery Drivers', 6, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_level` (`user_level`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_level` (`group_level`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=351;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=591;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `SK` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_level`) REFERENCES `user_groups` (`group_level`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
