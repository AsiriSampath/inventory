<?php

$con = mysqli_connect("localhost","root","","inventory_system");

if(!$con){
    echo "Connection Failed" . mysqli_connect_error();
}
?>