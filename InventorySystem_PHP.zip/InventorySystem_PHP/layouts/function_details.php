<?php
 function find_all_sale(){
    global $db;
    $sql  = "SELECT s.id, s.qty, s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name,s.added_by,s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by";
    $sql .= " FROM sales s";
    $sql .= " LEFT JOIN products p ON s.product_id = p.id";
    $sql .= " LEFT JOIN users u ON s.added_by = u.username";
    $sql .= " ORDER BY s.date DESC";
    return find_by_sql($sql);
  }
  function join_product_table()
   {
     global $db;
     $sql = "SELECT p.id,p.name,p.quantity,p.buy_price,p.sale_price,p.date,p.media_id,p.categorie_id,p.updated_at,p.updated_by,";
     $sql .= "c.name AS categorie, m.file_name AS image ";
     $sql .= "FROM products p ";
     $sql .= "LEFT JOIN categories c ON c.id = p.categorie_id ";
     $sql .= "LEFT JOIN media m ON m.id = p.media_id ";
     $sql .= "ORDER BY p.id ASC";
     return find_by_sql($sql);
   }
   function find_all_user(){
    global $db;
    $results = array();
    $sql = "SELECT u.id, u.name, u.username, u.email, u.phone_no, u.user_level, u.status, u.last_login, image, ";
    $sql .= "g.group_name ";
    $sql .= "FROM users u ";
    $sql .= "LEFT JOIN user_groups g ";
    $sql .= "ON g.group_level = u.user_level ";
    $sql .= "ORDER BY u.name ASC";
    $result = find_by_sql($sql);
    return $result;
}
$functionDetails = array(
  "find_all_sale" => "function find_all_sale(){
                        global $db;
                        $sql  = \"SELECT s.id, s.qty, s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name,s.added_by,s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by\";
                        $sql .= \" FROM sales s\";
                        $sql .= \" LEFT JOIN products p ON s.product_id = p.id\";
                        $sql .= \" LEFT JOIN users u ON s.added_by = u.username\";
                        $sql .= \" ORDER BY s.date DESC\";
                        return find_by_sql($sql);
                      }",
  "join_product_table" => "function join_product_table()
                          {
                            global $db;
                            $sql = \"SELECT p.id,p.name,p.quantity,p.buy_price,p.sale_price,p.date,p.media_id,p.categorie_id,p.updated_at,p.updated_by,\";
                            $sql .= \"c.name AS categorie, m.file_name AS image \";
                            $sql .= \"FROM products p \";
                            $sql .= \"LEFT JOIN categories c ON c.id = p.categorie_id \";
                            $sql .= \"LEFT JOIN media m ON m.id = p.media_id \";
                            $sql .= \"ORDER BY p.id ASC\";
                            return find_by_sql($sql);
                          }",
  "find_all_user" => "function find_all_user(){
                        global $db;
                        $results = array();
                        $sql = \"SELECT u.id, u.name, u.username, u.email, u.phone_no, u.user_level, u.status, u.last_login, image, \";
                        $sql .= \"g.group_name \";
                        $sql .= \"FROM users u \";
                        $sql .= \"LEFT JOIN user_groups g \";
                        $sql .= \"ON g.group_level = u.user_level \";
                        $sql .= \"ORDER BY u.name ASC\";
                        $result = find_by_sql($sql);
                        return $result;
                    }",
);

$functionName = $_GET["function"];
if (array_key_exists($functionName, $functionDetails)) {
  echo "<pre>" . htmlspecialchars($functionDetails[$functionName]) . "</pre>";
} else {
  echo "Function details not found.";
}
?>
