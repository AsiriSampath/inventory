<?php $user = current_user();
       $page_title = !empty($page_title) ? remove_junk($page_title) : (!empty($user) ? ucfirst($user['name']) : "Inventory Management System"); ?>
<!DOCTYPE html>
  <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title><?php if (!empty($page_title))
           echo remove_junk($page_title);
            elseif(!empty($user))
           echo ucfirst($user['name']);
            else echo "Inventory Management System";?>
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css">
    <link rel="stylesheet" href="libs/css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
@media (max-width: 767px) {
  .table-container {
    overflow-x: auto;
  }
  .table-responsive {
    width: 100%;
    margin-bottom: 15px;
    overflow-y: hidden;
    -ms-overflow-style: -ms-autohiding-scrollbar;
    border: 1px solid #ddd;
  }
}
</style>
  </head>
  <body>
  <?php  if ($session->isUserLoggedIn(true)): ?>
    <header id="header">
      <div class="logo pull-left"> Gadget Sri Lanka</div>
      <div class="header-content">
      <div class="header-date pull-left">
        <?php
          date_default_timezone_set('Asia/Colombo'); 
          $dateTime = date("F j, Y, g:i a");
          echo "<strong>" . $dateTime . "</strong>";
          ?>
      </div>
      <div class="pull-right clearfix">
        <ul class="info-menu list-inline list-unstyled">
          <li class="profile">
            <a href="#" data-toggle="dropdown" class="toggle" aria-expanded="false">
              <img src="uploads/users/<?php echo $user['image'];?>" alt="user-image" class="img-circle img-inline">
              <span><?php echo remove_junk(ucfirst($user['name'])); ?> <i class="caret"></i></span>
            </a>
            <ul class="dropdown-menu">
              <li>
                  <a href="profile.php?id=<?php echo (int)$user['id'];?>">
                      <i class="glyphicon glyphicon-user"></i>
                      Profile
                  </a>
              </li>
             <li>
             <?php if ($user['user_level'] === '1'): ?>
                 <a href="edit_account.php" title="edit account">
                     <i class="glyphicon glyphicon-cog"></i>
                     Settings
                 </a>
                 <?php endif; ?>
             </li>
             <li class="last">
              <a href="#" onclick="showLogoutWarning()">
                <i class="glyphicon glyphicon-off"></i>
                Logout
              </a>
              <script>
                function showLogoutWarning() {
                  Swal.fire({
                    title: 'Logout',
                    text: 'Are you sure you want to logout?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, logout!'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      // User confirmed the logout, perform logout action here
                      window.location.href = 'logout.php';
                    }
                  });
                }
                </script>
              </li>
           </ul>
          </li>
        </ul>
      </div>
<style>
  .search {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
  }

  .search input[type="text"] {
    width: 100%;
    max-width: 300px;
    border: 1px solid #ccc;
    border-radius: none;
    outline: none;
  }

  .search .input-group-btn {
    white-space: nowrap;
  }

  .search .btn {
    height: 34px;
    border-radius: none;
    background-color:#bf3522;
    border-color:#bf3522;
  }
  .search .btn:hover{
    background-color:#8a2315;
  }

  @media (max-width: 767px) {
    .search {
      flex-direction: column;
      margin-bottom: 10px;
    }

    .search input[type="text"] {
      max-width: none;
    }
  }
</style>

    </header>
    <div class="sidebar">
      <?php if($user['user_level'] === '1'): ?>
        <!-- admin menu -->
      <?php include_once('admin_menu.php');?>

      <?php elseif($user['user_level'] === '2'): ?>
        <!-- manager -->
      <?php include_once('manager_menu.php');?>

      <?php elseif($user['user_level'] === '3'): ?>
        <!-- staff menu -->
      <?php include_once('staff_menu.php');?>

      <?php elseif($user['user_level'] === '4'): ?>
        <!-- seller menu -->
      <?php include_once('seller_menu.php');?>

      <?php elseif($user['user_level'] === '5'): ?>
        <!-- partner menu -->
      <?php include_once('partner_menu.php');?>

      <?php elseif($user['user_level'] === '6'): ?>
        <!-- delivery menu -->
      <?php include_once('delivery_drivers_menu.php');?>

      <?php endif;?>

   </div>
<?php endif;?>

<div class="page">
  <div class="container-fluid">