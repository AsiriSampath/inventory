<?php

include("config.php");
if(isset($_POST['input'])){

    $input = $_POST['input'];

    $query = "SELECT * FROM sales WHERE id LIKE '{$input}%' OR qty LIKE '{$input}%' OR price LIKE '{$input}%' OR date LIKE '{$input}%'";

    $result = mysqli_query($con,$query);

    if(mysqli_num_rows($result) > 0){?>

    <table class= "table tabel-bordered table-striped mt-4">
        <thead>
            <tr>
                <th>id</th>
                <th>product_id</th>
                <th>qty</th>
                <th>price</th>
                <th>date</th>
                <th>customer_phone</th>
                <th>customer_name</th>
            </tr>
        </thead>
    </table>

    <tbody>
    <?php
        while($row = mysqli_fetch_assoc($result)){

            $id = $row['id'];
            $product_id = $row['product_id'];
            $qty = $row['qty'];
            $price = $row['price'];
            $date = $row['date'];
            $customer_phone = $row['customer_phone'];
            $customer_name = $row['customer_name'];

            ?>
                <tr>
                    <th><?php echo $id;?></th>
                    <th><?php echo $product_id;?></th>
                    <th><?php echo $qty;?></th>
                    <th><?php echo $price;?></th>
                    <th><?php echo $date;?></th>
                    <th><?php echo $customer_phone;?></th>
                    <th><?php echo $customer_name;?></th>
                </tr>
            <?php
        }
        ?>
    </tbody>

        <?php
    }else{
        echo "<h6 class='text-danger text-center mt-3'>No Data Found</h6>";
    }
}
?>