<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Manage product</a> </li>
   </ul>
  </li>
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Media</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-credit-card"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">Manage Sales</a> </li>
     </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-duplicate"></i>
       <span>Sales Report</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sales_report.php">Sales by dates </a></li>
        <li><a href="monthly_sales.php">Monthly sales</a></li>
        <li><a href="daily_sales.php">Daily sales</a> </li>
      </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-File"></i>
       <span>Salers Details</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sellers_report.php">Seller Reports </a></li>
        <li><a href="staff_report.php">Staff Reports</a></li>
        <li><a href="partners_report.php">Partners Reports</a> </li>
        <li><a href="products_report.php">Product Reports</a> </li>
      </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-plane"></i>
       <span>Delivery Details</span>
      </a>
      <ul class="nav submenu">
        <li><a href="delivery_drivers_report.php">Delivery Drivers</a> </li>
      </ul>
    </li>
    <li>
    <a href="customer_report.php" >
      <i class="glyphicon glyphicon-thumbs-up"></i>
      <span>Customer Report</span>
    </a>
  </li>  
    <style>
        /* Menu styles */
.menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.menu li {
  position: relative;
}

.menu a {
  display: block;
  padding: 10px;
  text-decoration: none;
  color: #333;
  transition: background-color 0.3s;
}

.menu a:hover {
  background-color: #f5f5f5;
}

.menu i {
  margin-right: 10px;
}

.menu .submenu-toggle::after {
  content: '\25BE';
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
}

.menu .submenu {
  display: none;
  list-style: none;
  padding-left: 20px;
  margin: 0;
}

.menu .submenu li {
  position: relative;
}

.menu .submenu a {
  padding: 5px;
}

.menu .submenu-toggle:hover + .submenu,
.menu .submenu:hover {
  display: block;
}

/* Animation styles */
@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

.animated {
  animation-duration: 1s;
  animation-fill-mode: both;
}

.fadeIn {
  animation-name: fadeIn;
}

      </style>
</ul>
