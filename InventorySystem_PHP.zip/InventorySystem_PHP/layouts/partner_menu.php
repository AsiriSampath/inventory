<ul>
  <li>
    <a href="admin_by_user.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product_by_user.php">Manage Products</a> </li>
   </ul>
  </li>
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Media</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales_by_user.php">Manage Sales</a> </li>
     </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>Sales Report</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sales_report_by_user.php">Sales by dates </a></li>
        <li><a href="monthly_sales_by_user.php">Monthly sales</a></li>
        <li><a href="daily_sales_by_user.php">Daily sales</a> </li>
      </ul>
  </li>
  <style>
        /* Menu styles */
.menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.menu li {
  position: relative;
}

.menu a {
  display: block;
  padding: 10px;
  text-decoration: none;
  color: #333;
  transition: background-color 0.3s;
}

.menu a:hover {
  background-color: #f5f5f5;
}

.menu i {
  margin-right: 10px;
}

.menu .submenu-toggle::after {
  content: '\25BE';
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
}

.menu .submenu {
  display: none;
  list-style: none;
  padding-left: 20px;
  margin: 0;
}

.menu .submenu li {
  position: relative;
}

.menu .submenu a {
  padding: 5px;
}

.menu .submenu-toggle:hover + .submenu,
.menu .submenu:hover {
  display: block;
}

/* Animation styles */
@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

.animated {
  animation-duration: 1s;
  animation-fill-mode: both;
}

.fadeIn {
  animation-name: fadeIn;
}

      </style>
</ul>