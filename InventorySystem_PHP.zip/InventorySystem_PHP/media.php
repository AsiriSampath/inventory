<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  $page_title = 'All Image';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(5);
?>
<?php $media_files = find_all('media');?>
<?php
  if(isset($_POST['submit'])) {
  $photo = new Media();
  $photo->upload($_FILES['file_upload']);  
    if ($photo->process_media()) {
      // Success
      echo "<script>
        Swal.fire({
          icon: 'success',
          title: 'Photo has been uploaded!',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'media.php';
          }
        });
      </script>";
    } else {
      // Failure
      echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Failed to upload photo',
          text: '" . join($photo->errors) . "',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'media.php';
          }
        });
      </script>";
    }
    
  }

?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">  
      <div class="panel-heading">
     <strong>
          <span class="glyphicon glyphicon-camera"></span>
          <span>ALL PHOTOS</span>
        </strong>
        <div class="pull-right">
          <form class="form-inline" action="media.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
              <div class="input-group">
              <div class="form-group">
  <label for="file_upload" class="control-label">Upload Files</label>
  <div class="btn btn-default btn-file">
    <input type="file" name="file_upload" multiple="multiple" />
  </div>
</div>
<style>
  /* Style the file input button */
.btn-file {
  position: relative;
  overflow: hidden;
}

/* Style the actual file input element */
.btn-file input[type="file"] {
  position: absolute;
  top: 0;
  right: 0;
  min-width: 100%;
  min-height: 100%;
  font-size: 100px;
  text-align: right;
  filter: alpha(opacity=0);
  opacity: 0;
  outline: none;
  background: white;
  cursor: inherit;
  display: block;
}

/* Add some styling when hovering over the file input button */
.btn-file:hover {
  background-color: #f5f5f5;
}

/* Add some padding to the file input button */
.btn-file::before {
  content: "Browse";
  display: inline-block;
  background: #428bca;
  color: white;
  padding: 6px 12px;
  border-radius: 4px;
  cursor: pointer;
}

/* Add styling when hovering over the "Browse" text */
.btn-file:hover::before {
  background: #357ebd;
}

</style>
                <button type="submit" name="submit" class="btn btn-default"><i class="fa fa-upload" aria-hidden="true"></i></button>
              </div>
             </div>
            </div>
          </form>
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th class="text-center">#</th>
                <th class="text-center">Photo</th>
                <th class="text-center">Photo Name</th>
                <th class="text-center" style="width: 20%;">Photo Type</th>
                <?php if ($user['user_level'] === '1'|| $user['user_level'] === '2' || $user['user_level'] === '3' ) : ?>
                <th class="text-center" style="width: 50px;">Actions</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($media_files as $media_file) : ?>
                <tr class="list-inline">
                  <td class="text-center"><?php echo $media_file['id']; ?></td>
                  <td class="text-center">
                    <img src="uploads/products/<?php echo $media_file['file_name']; ?>" class="img-thumbnail" />
                  </td>
                  <td class="text-center">
                    <?php echo $media_file['file_name']; ?>
                  </td>
                  <td class="text-center">
                    <?php echo $media_file['file_type']; ?>
                  </td>
                  <?php if ($user['user_level'] === '1'|| $user['user_level'] === '2' || $user['user_level'] === '3' ) : ?>
                  <td class="text-center">
                    <a href="#" class="btn btn-danger btn-xs" title="Edit" onclick="confirmDelete(<?php echo (int)$media_file['id']; ?>)">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                    <?php endif; ?>
                    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                    <script>
                      function confirmDelete(mediaId) {
                        Swal.fire({
                          title: 'Are you sure?',
                          text: 'You will not be able to recover this photo!',
                          icon: 'warning',
                          showCancelButton: true,
                          confirmButtonColor: '#3085d6',
                          cancelButtonColor: '#d33',
                          confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                          if (result.isConfirmed) {
                            // User confirmed the delete action
                            // Redirect to delete_media.php with the media ID
                            window.location.href = 'delete_media.php?id=' + mediaId;
                          }
                        });
                      }
                    </script>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
