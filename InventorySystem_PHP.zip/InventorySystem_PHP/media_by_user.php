<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  $page_title = 'All Image';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(5);
?>
<?php  $uid = $_SESSION['uid'];
  $media_files = find_all_u('media', 'uid');
?>
<?php
  if(isset($_POST['submit'])) {
  $photo = new Media();
  $photo->upload($_FILES['file_upload']);  
    if ($photo->process_media()) {
      // Success
      echo "<script>
        Swal.fire({
          icon: 'success',
          title: 'Photo has been uploaded!',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'media.php';
          }
        });
      </script>";
    } else {
      // Failure
      echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Failed to upload photo',
          text: '" . join($photo->errors) . "',
          showConfirmButton: false,
          timer: 1500,
          didClose: () => {
            window.location.href = 'media.php';
          }
        });
      </script>";
    }
    
  }

?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">  
      <div class="panel-heading">
     <strong>
          <span class="glyphicon glyphicon-camera"></span>
          <span>ALL PHOTOS</span>
        </strong>
        <div class="pull-right">
          <form class="form-inline" action="media_by_user.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
              <div class="input-group">
              <span class="input-group-btn">
                  <input type="file" name="file_upload" multiple="multiple" class="btn btn-primary btn-file" />
                </span>
                <button type="submit" name="submit" class="btn btn-default">Upload</button>
              </div>
             </div>
            </div>
          </form>
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th class="text-center">#</th>
                <th class="text-center">Photo</th>
                <th class="text-center">Photo Name</th>
                <th class="text-center" style="width: 20%;">Photo Type</th>
                <th class="text-center" style="width: 50px;">Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($media_files as $media_file) : ?>
                <tr class="list-inline">
                  <td class="text-center"><?php echo $media_file['id']; ?></td>
                  <td class="text-center">
                    <img src="uploads/products/<?php echo $media_file['file_name']; ?>" class="img-thumbnail" />
                  </td>
                  <td class="text-center">
                    <?php echo $media_file['file_name']; ?>
                  </td>
                  <td class="text-center">
                    <?php echo $media_file['file_type']; ?>
                  </td>
                  <td class="text-center">
                    <a href="#" class="btn btn-danger btn-xs" title="Edit" onclick="confirmDelete(<?php echo (int)$media_file['id']; ?>)">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                    <script>
                      function confirmDelete(mediaId) {
                        Swal.fire({
                          title: 'Are you sure?',
                          text: 'You will not be able to recover this photo!',
                          icon: 'warning',
                          showCancelButton: true,
                          confirmButtonColor: '#3085d6',
                          cancelButtonColor: '#d33',
                          confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                          if (result.isConfirmed) {
                            // User confirmed the delete action
                            // Redirect to delete_media.php with the media ID
                            window.location.href = 'delete_media.php?id=' + mediaId;
                          }
                        });
                      }
                    </script>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
