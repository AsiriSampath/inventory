<?php
  $page_title = 'Partner Report';
  require_once('includes/load.php');
  page_require_level(2);
  $all_partner = find_all_partner();
?>
<?php
if (isset($_POST['submit'])) {
  $req_dates = array('start-date', 'end-date', 'partner-id');
  validate_fields($req_dates);

  if (empty($errors)) {
      $start_date = remove_junk($db->escape($_POST['start-date']));
      $end_date = remove_junk($db->escape($_POST['end-date']));
      $staff_id = remove_junk($db->escape($_POST['partner-id']));
      $results = generate_partner_sales_report($partner_id, $start_date, $end_date);
  } else {
      $session->msg("d", $errors);
      redirect('partners_report.php', false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <div class="panel">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Generate Partners Report</span>
        </strong>
      </div>
      <div class="panel-body">
        <form class="clearfix" method="post" action="partners_report_process.php">
        <div class="form-group">
          <label class="form-label">Partners</label>
          <select class="form-control" name="partner-id" required>
            <option value="">Select Partners</option>
            <option value="all">All Partners</option>
            <?php foreach ($all_partner as $partner): ?>
              <option value="<?php echo $partner['id']; ?>"><?php echo $partner['name']; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
          <div class="form-group">
            <label class="form-label">Date Range</label>
            <div class="input-group">
              <input type="text" class="datepicker form-control" name="start-date" placeholder="From">
              <span class="input-group-addon"><i class="glyphicon glyphicon-menu-right"></i></span>
              <input type="text" class="datepicker form-control" name="end-date" placeholder="To">
            </div>
          </div>
          <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary">Generate Report <i class="fa fa-cogs" aria-hidden="true"></i></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<style>
.panel {
  margin-top: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.panel-heading {
  background-color: #fdfaf3;
  border-bottom: 2px solid #364c6f;
  padding: 10px;
}

.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 18px;
}

.panel-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-label {
  font-weight: bold;
}

.form-control {
  width: 100%;
}

@media (max-width: 768px) {
  .col-md-6 {
    width: 100%;
  }
}
</style>
<?php include_once('layouts/footer.php'); ?>