<!-- process_sales.php -->

<?php
  $page_title = 'Process Sales';
  require_once('includes/load.php');
  page_require_level(3);
?>

<?php
  if (isset($_POST['add_sales'])) {
    $selected_products = $_POST['product'];
    $quantities = $_POST['quantity'];

    $errors = array();

    foreach ($selected_products as $key => $p_id) {
      $quantity = (int)$quantities[$key];
      $product = find_by_id('products', $p_id);
      $product_quantity = remove_junk($product['quantity']);

      if ($quantity <= 0) {
        $errors[] = "Invalid quantity for product with ID: $p_id";
      } elseif ($product_quantity < $quantity) {
        $errors[] = "Insufficient stock for product with ID: $p_id";
      }
    }

    if (empty($errors)) {
      foreach ($selected_products as $key => $p_id) {
        $quantity = (int)$quantities[$key];
        $product = find_by_id('products', $p_id);
        $product_quantity = remove_junk($product['quantity']);

        $s_total   = $product['price'] * $quantity;
        $s_customer_name   = $db->escape($_POST['customer_name']);
        $s_customer_email   = $db->escape($_POST['customer_email']);
        $s_customer_phone   = $db->escape($_POST['customer_phone']);
        $date      = $db->escape($_POST['date']);
        $s_date    = make_date();

        $sql  = "INSERT INTO sales (";
        $sql .= " product_id, qty, price, customer_name, customer_email, customer_phone, date";
        $sql .= ") VALUES (";
        $sql .= "'{$p_id}', '{$quantity}', '{$s_total}', '{$s_customer_name}', '{$s_customer_email}', '{$s_customer_phone}', '{$s_date}'";
        $sql .= ")";

        if ($db->query($sql)) {
          update_product_qty($quantity, $p_id);
        } else {
          $errors[] = "Failed to add sale for product with ID: $p_id";
        }
      }

      if (empty($errors)) {
        $session->msg("s", "Sales added successfully!");
        redirect('add_sale.php', false);
      } else {
        $session->msg("d", $errors);
        redirect('add_sale.php', false);
      }
    } else {
      $session->msg("d", $errors);
      redirect('add_sale.php', false);
    }
  }
?>
