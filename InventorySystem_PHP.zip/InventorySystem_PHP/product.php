<?php
$page_title = 'All Product';
require_once('includes/load.php');
// Checking what level user has permission to view this page
page_require_level(6);
$products = join_product_table();
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
      <div class="panel-heading">
     <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>PRODUCTS</span>
        </strong>
        <div class="pull-right">
          <a href="add_product.php" class="btn btn-primary"><i class="fa fa-plus-square" aria-hidden="true"></i></a>
        </div>
      </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">#</th>
                <th> Photo</th>
                <th> Product Title </th>
                <th class="text-center" style="width: 10%;"> Categories </th>
                <th class="text-center" style="width: 10%;"> In-Stock </th>
                <th class="text-center" style="width: 10%;"> Buying Price </th>
                <th class="text-center" style="width: 10%;"> Selling Price </th>
                <th class="text-center" style="width: 10%;"> Product Added (Id) </th>
                <?php if ($user['user_level'] === '1'|| $user['user_level'] === '2') : ?>
                <th class="text-center" style="width: 10%;"> Last Updated </th>
                <?php endif; ?>
                  <th class="text-center" style="width: 100px;"> Actions </th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($products as $product) : ?>
                <tr>
                <td class="text-center"> <?php echo remove_junk($product['id']); ?></td>
                  <td>
                    <?php if ($product['media_id'] === '0') : ?>
                      <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                    <?php else : ?>
                      <img class="img-avatar img-circle" src="uploads/products/<?php echo $product['image']; ?>" alt="">
                    <?php endif; ?>
                  </td>
                  <td> <?php echo remove_junk($product['name']); ?></td>
                  <td class="text-center"> <?php echo remove_junk($product['categorie']); ?></td>
                  <td class="text-center">
                    <?php
                    $quantity = remove_junk($product['quantity']);
                    if ($quantity <= 0) {
                      echo '<span class="out-of-stock">Out of Stock</span>';
                    } else {
                      echo $quantity;
                    }
                    ?>
                  </td>
                  <style>
                    .out-of-stock {
                      color: red;
                      font-weight: bold;
                    }
                  </style>
                  <td class="text-center"> <?php echo remove_junk($product['buy_price']); ?></td>
                  <td class="text-center"> <?php echo remove_junk($product['sale_price']); ?></td>
                  <td class="text-center">
                     <?php
                      echo read_date($product['date']);

                      echo "<br>";

                      echo '<span style="font-weight: bold; color: black;">' . remove_junk($product['p_user_id']) . '</span>';
                       ?></td>
                  <?php if ($user['user_level'] === '1'|| $user['user_level'] === '2') : ?>
                    <td class="text-center">
                        <?php
                        echo read_date($product['updated_at']);
                        ?>
                    </td>
                  <?php endif; ?>
                  <td class="text-center">
                    <div class="btn-group">
                        <a href="edit_product.php?id=<?php echo (int)$product['id']; ?>" class="btn btn-warning btn-xs" title="Edit" data-toggle="tooltip">
                          <span class="glyphicon glyphicon-edit"></span>
                        </a>
                      <?php if ($user['user_level'] === '1') : ?>
                        <a href="#" class="btn btn-danger btn-xs" title="Delete" data-toggle="tooltip" onclick="confirmDelete(<?php echo (int)$product['id']; ?>)">
                          <span class="glyphicon glyphicon-trash"></span>
                        </a>
                      <?php endif; ?>
                      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                      <script>
                        function confirmDelete(productId) {
                          Swal.fire({
                            title: 'Are you sure?',
                            text: 'You will not be able to recover this product!',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href = 'delete_product.php?id=' + productId;
                            }
                          });
                        }
                      </script>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>