<?php
  $page_title = 'My profile';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(5);
?>
<?php
  $user_id = (int)$_GET['id'];
  if (empty($user_id)):
    redirect('home.php', false);
  else:
    $user_p = find_by_id('users', $user_id);
  endif;
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-4">
    <div class="panel profile">
      <div class="jumbotron text-center bg-black">
        <img class="img-circle img-size-2" src="uploads/users/<?php echo $user_p['image'];?>" alt="">
        <h3><?php echo first_character($user_p['name']); ?></h3>
      </div>
      <?php if ($user_p['id'] === $user['id']):?>
          <ul class="nav nav-pills nav-stacked">
            <li><a href="edit_account.php"><i class="glyphicon glyphicon-edit"></i> Edit profile</a></li>
            <style>
               .nav-pills {
                padding-left: 0;
                list-style: none;
              }

              .nav-stacked > li {
                display: block;
              }

              .nav-stacked > li > a {
                position: relative;
                display: block;
                padding: 10px 15px;
                margin-bottom: -1px;
                background-color: #f8f8f8;
                border: 1px solid #ddd;
                color: #333;
              }

              .nav-stacked > li > a:hover,
              .nav-stacked > li > a:focus {
                background-color: #e7e7e7;
              }

              .nav-stacked > li > a > i {
                margin-right: 10px;
              }

            </style>
          </ul>
      <?php endif;?>
    </div>
  </div>
</div>
<style>
  /* General styles */
  .panel.profile {
    margin-bottom: 20px;
  }

  .jumbotron.text-center {
    margin-bottom: 20px;
  }

  .bg-red {
    background-color: #999;
  }

  .img-circle.img-size-2 {
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }

  /* Mobile-specific styles */
  @media (max-width: 767px) {
    .col-md-4 {
      width: 100%;
    }

    .panel.profile {
      margin-left: 0;
      margin-right: 0;
    }
  }
</style>

<?php include_once('layouts/footer.php'); ?>
