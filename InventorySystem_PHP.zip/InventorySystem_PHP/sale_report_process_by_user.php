<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">
<?php
$page_title = 'Sales Report';
$results = '';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(5);
?>
<?php
  if(isset($_POST['submit'])){
    $req_dates = array('start-date','end-date');
    validate_fields($req_dates);

    if(empty($errors)):
      $username = $_SESSION['username'];
      $start_date   = remove_junk($db->escape($_POST['start-date']));
      $end_date     = remove_junk($db->escape($_POST['end-date']));
      $results      = find_sale_by_dates_u($start_date, $end_date, $username);
    else:
      $session->msg("d", $errors);
      redirect('sales_report_by_user.php', false);
    endif;

  } else {
    $session->msg("d", "Select dates");
    redirect('sales_report_by_user.php', false);
  }
?>
<!doctype html>
<html lang="en-US">
 <head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title><?php echo date('Y-m-d') . ' ' . ' Sales PDF Report'; ?></title>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>
     <style>
   @media print {
     html,body{
        font-size: 9.5pt;
        margin: 0;
        padding: 0;
     }.page-break {
       page-break-before:always;
       width: auto;
       margin: auto;
      }
    }
    .page-break{
      width: 980px;
      margin: 0 auto;
    }
     .sale-head{
       margin: 40px 0;
       text-align: center;
     }.sale-head h1,.sale-head strong{
       padding: 10px 20px;
       display: block;
     }.sale-head h1{
       margin: 0;
       border-bottom: 1px solid #212121;
     }.table>thead:first-child>tr:first-child>th{
       border-top: 1px solid #000;
      }
      table thead tr th {
       text-align: center;
       border: 1px solid #ededed;
     }table tbody tr td{
       vertical-align: middle;
     }.sale-head,table.table thead tr th,table tbody tr td,table tfoot tr td{
       border: 1px solid #212121;
       white-space: nowrap;
     }.sale-head h1,table thead tr th,table tfoot tr td{
       background-color: #f8f8f8;
     }tfoot{
       color:#000;
       text-transform: uppercase;
       font-weight: 500;
     }
   </style>
</head>
<body>
  <?php if($results): ?>
    <div class="page-break">
       <div class="sale-head">
           <h1>Gadget SriLanka Management System - Sales Report</h1>
           <strong><?php if(isset($start_date)){ echo $start_date;}?> TILL DATE <?php if(isset($end_date)){echo $end_date;}?> </strong>
       </div>
       <style>
    @media print {
      .text-center, .pagination {
        display: none;
      }
      table {
        font-size: 10px;
      }
      th, td {
        padding: 4px;

      }
    }
  </style>  
            <div class="text-center">
              <button onclick="printReport()" class="btn btn-primary">Print Report</button>
            </div>

            <script>
            function printReport() {
              window.print();
            }
          </script>
             <div style="display: flex; justify-content: center;">
      <table class="table table-border">
        <thead>
        <tr>
          <th>id</th>
          <th>Date</th>
          <th>Product Title</th>
          <th>Customer Name</th>
          <th>Customer Phone</th>
          <th>Buying Price</th>
          <th>Selling Price</th>
          <th>Payment Method</th>
          <th>Delivery Amount</th>
          <th>Delivery Method</th>
          <th>Total Qty</th>
          <th>TOTAL</th>
        </tr>
        </thead>
        <tbody>
          <?php foreach($results as $result): ?>
            <tr>
            <td class="text-rught"><h6><?php echo remove_junk($result['id']); ?></h6></td>
              <td class=""><?php echo remove_junk($result['date']); ?></td>
              <td class="desc">
                <h6><?php echo remove_junk(ucfirst($result['name'])); ?></h6>
              </td>
              <td class="text-right"><h6><?php echo remove_junk($result['customer_name']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['customer_phone']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['buy_price']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['sale_price']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['payment_method']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['delivery_ammount']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['delivery_method']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['total_sales']); ?></h6></td>
              <td class="text-right"><h6><?php echo remove_junk($result['total_saleing_price']); ?></h6></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
         <tr class="text-right">
           <td colspan="10"></td>
           <td colspan="1">Grand Total</td>
           <td> 
           <?php echo number_format(total_price($results)[0], 2);?>
          </td>
         </tr>
         <tr class="text-right">
           <td colspan="10"></td>
           <td colspan="1">Profit</td>
           <td> <?php echo number_format(total_price($results)[1], 2);?></td>
         </tr>
        </tfoot>
      </table>
    </div>
  <?php
    else:
        $session->msg("d", "Sorry no sales has been found. ");
        redirect('sales_report_by_user.php', false);
     endif;
  ?>
</body>
<style>
  .table {
    width: 100%;
    text-align: center;
  }
  
  th, td {
    text-align: center;
    padding: 8px;
  }
  
  th {
    background-color: #f2f2f2;
  }
  
  tbody tr:nth-child(even) {
    background-color: #f2f2f2;
  }
  
  tfoot {
    font-weight: bold;
  }
</style>

</html>
<?php if(isset($db)) { $db->db_disconnect(); } ?>
