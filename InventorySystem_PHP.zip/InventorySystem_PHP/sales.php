<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php
  $page_title = 'All sale';
  require_once('includes/load.php');
  // Checking what level user has permission to view this page
  page_require_level(5);
?>
<?php
$sales = find_all_sale();
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row" style="position: relative">
  <div class="col-md-12">
    <form method="post" action="search.php">
        <input type="text" name="search_query" placeholder="Enter Customer Details">
        <button type="submit" name="search"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
    <style>
      /* CSS for the form container */
form {
  display: flex;
  max-width: 200px;
  margin-top: 20px;
}

/* CSS for the search input */
input[type="text"] {
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px 0 0 5px;
  outline: none;
}

/* CSS for the search button */
button {
  padding: 10px 20px;
  background-color: #080075;
  color: #fff;
  border: none;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
}

/* Hover styles for the search button */
button:hover {
  background-color: #080359;
}

/* Responsive adjustments */
@media (max-width: 500px) {
  form {
    flex-direction: column;
    max-width: 300px;
    margin: 20px auto;
  }

  input[type="text"] {
    border-radius: 5px;
    margin-bottom: 10px;
  }

  button {
    border-radius: 5px;
  }
}

    </style>
    <br>
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
        <span class="glyphicon glyphicon-th"></span>
          <span>All Sales</span>
        </strong>
        <div class="pull-right">
          <!-- <?php if ($user['user_level'] === '1'): ?>
            <button id="bulk-delete-btn" class="btn btn-danger">Delete Selected</button>
          <?php endif; ?> -->
          <a href="add_sale.php" class="btn btn-primary">Add sale <i class="fa fa-plus-square" aria-hidden="true"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <div style="overflow: auto; max-height: 500px;">
            <table class="table table-bordered table-striped sticky-header">
            <thead>
              <style>
                .sticky-header {
                  position: sticky;
                  top: 0;
                  background-color: #fff;
                }
              </style>
              <tr class="sticky-header">
                <th class="text-center" >#</th>
                <th class="text-center" >Date</th>
                <th class="text-center" >Customer Name</th>
                <th class="text-center" >Product Name</th>
                <th class="text-center" >Quantity</th>
                <th class="text-center" >Payment Method</th>
                <th class="text-center" >Delivery Amount</th>
                <th class="text-center" >Delivery Method</th>
                <th class="text-center" >Discount Amount</th>
                <th class="text-center" >Description</th>
                <th class="text-center" >Customer Email</th>
                <th class="text-center" >Customer Phone</th>
                <th class="text-center" >Address</th>
                <th class="text-center" >Sold By</th>
                <th class="text-center" >Total</th>
                <?php if ($user['user_level'] === '1'): ?>
                  <th class="text-center" >Added By (Id)</th>
                  <?php endif; ?>
                  <th class="text-center" >Actions</th>
              </tr>
            </thead>
              <tbody>
                <?php foreach ($sales as $sale): ?>
                  <tr>
                    <td class="text-center"><?php echo remove_junk($sale['id']);?></td>
                    <td class="text-center"><?php echo $sale['date']; ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['customer_name']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['name']); ?></td>
                    <td class="text-center"><?php echo (int)$sale['qty']; ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['payment_method']); ?></td>
                    <td class="text-center">
                      <?php
                      echo empty($sale['delivery_ammount']) ? 'N/A' : remove_junk($sale['delivery_ammount']);
                      echo "<br>";

                      if ($sale['delivery_method'] === 'COD') {
                          echo '<span id="selectedDriverName">' . remove_junk($sale['place_by']) . '</span>';
                      } else {
                          echo 'N/A';
                      }
                      ?>
                  </td>
                    <td class="text-center"><?php echo remove_junk($sale['delivery_method']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['discount_amount']) ?></td>
                    <td class="text-center">
                    <span class="description-link" data-description="<?php echo remove_junk($sale['description']); ?>">
                      <a href="#" class="highlight-link">
                        <?php echo substr(remove_junk($sale['description']), 0, 10); ?>...
                      </a>
                    </span>
                  </td>
                  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                    <script>
                      document.addEventListener('DOMContentLoaded', function() {
                        const highlightLinks = document.getElementsByClassName('highlight-link');

                        Array.from(highlightLinks).forEach(function(link) {
                          link.addEventListener('click', function(e) {
                            e.preventDefault();

                            const description = this.parentElement.dataset.description;

                            Swal.fire({
                              title: 'Description',
                              html: `<span class="highlight">${description}</span>`,
                              confirmButtonText: 'Close',
                            });
                          });
                        });
                      });
                    </script>
                    <td class="text-center"><?php echo remove_junk($sale['customer_email']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['customer_phone']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['address']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['place_by']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['price']); ?></td>
                    <?php if ($user['user_level'] === '1'): ?>
                      <td class="text-center"><?php echo remove_junk($sale['added_by']);
                                                    echo "<br>";
                                                    echo '<span style="font-weight: bold; color: black;">' . remove_junk($sale['user_id']) . '</span>';?>
                    </td>
                      <?php endif; ?>
                      <td class="text-center">
                        <div class="btn-group">
                          <a href="edit_sale.php?id=<?php echo (int)$sale['id']; ?>" class="btn btn-warning btn-xs" title="Edit" data-toggle="tooltip">
                            <span class="glyphicon glyphicon-edit"></span>
                          </a>
                          <?php if ($user['user_level'] === '1'): ?>
                          <a href="#" class="btn btn-danger btn-xs" title="Delete" onclick="confirmDelete(<?php echo (int)$sale['id']; ?>)">
                            <span class="glyphicon glyphicon-trash"></span>
                          </a>
                          <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                      <script>
                        function confirmDelete(productId) {
                          Swal.fire({
                            title: 'Are you sure?',
                            text: 'You will not be able to recover this Sale!',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              // User confirmed the delete action
                              // Redirect to delete_product.php with the product ID
                              window.location.href = 'delete_sale.php?id=' + productId;
                            }
                          });
                        }
                      </script>
                          <!-- <input type="checkbox" class="delete-checkbox" value="<?php echo (int)$sale['id']; ?>"> -->
                        </div>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?> 