<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php
$page_title = 'All sale';
require_once('includes/load.php');
// Checking what level user has permission to view this page
page_require_level(5);

$username = $_SESSION['username']; 
$sales = find_all_sale_u($username);

include_once('layouts/header.php');
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row" style="position: relative">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>All Sales</span>
        </strong>
        <div class="pull-right">
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <div style="overflow: auto; max-height: 700px;">
            <table class="table table-bordered table-striped sticky-header">
            <thead>
              <style>
                .sticky-header {
                  position: sticky;
                  top: 0;
                  background-color: #fff;
                }
              </style>
              <tr class="sticky-header">
                <th class="text-center" style="width: 50px;">#</th>
                <th class="text-center" style="width: 10%;">Date</th>
                <th class="text-center" style="width: 10%;">Customer Name</th>
                <th class="text-center" style="width: 15%;">Product Name</th>
                <th class="text-center" style="width: 10%;">Price</th>
                <th class="text-center" style="width: 60px;">Quantity</th>
                <th class="text-center" style="width: 10%;">Payment Method</th>
                <th class="text-center" style="width: 10%;">Delivery Amount</th>
                <th class="text-center" style="width: 10%;">Delivery Method</th>
                <th class="text-center" style="width: 10%;">Discount Amount</th>
                <th class="text-center" style="width: 15%;">Description</th>
                <th class="text-center" style="width: 10%;">Customer Email</th>
                <th class="text-center" style="width: 10%;">Customer Phone</th>
                <th class="text-center" style="width: 10%;">Address</th>
                <th class="text-center" style="width: 10%;">Total</th>
                <?php if ($user['user_level'] === '1'): ?>
                  <th class="text-center" style="width: 15%;">Added By</th>
                  
                  <th class="text-center" style="width: 5%;">Actions</th>
                  <?php endif; ?>
              </tr>
            </thead>
              <tbody>
                <?php foreach ($sales as $sale): ?>
                  <tr>
                    <td class="text-center"><?php echo remove_junk($sale['id']);?></td>
                    <td class="text-center"><?php echo $sale['date']; ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['customer_name']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['name']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['price']); ?></td>
                    <td class="text-center"><?php echo (int)$sale['qty']; ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['payment_method']); ?></td>
                    <td class="text-center"><?php echo empty($sale['delivery_ammount']) ? 'N/A' : remove_junk($sale['delivery_ammount']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['delivery_method']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['discount_amount']) ?></td>
                    <td class="text-center">
                    <span class="description-link" data-description="<?php echo remove_junk($sale['description']); ?>">
                      <a href="#" class="highlight-link">
                        <?php echo substr(remove_junk($sale['description']), 0, 10); ?>...
                      </a>
                    </span>
                  </td>
                  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                    <script>
                      document.addEventListener('DOMContentLoaded', function() {
                        const highlightLinks = document.getElementsByClassName('highlight-link');

                        Array.from(highlightLinks).forEach(function(link) {
                          link.addEventListener('click', function(e) {
                            e.preventDefault();

                            const description = this.parentElement.dataset.description;

                            Swal.fire({
                              title: 'Description',
                              html: `<span class="highlight">${description}</span>`,
                              confirmButtonText: 'Close',
                            });
                          });
                        });
                      });
                    </script>
                    <td class="text-center"><?php echo remove_junk($sale['customer_email']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['customer_phone']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['address']); ?></td>
                    <td class="text-center"><?php echo remove_junk($sale['price']); ?></td>
                    <?php if ($user['user_level'] === '1'): ?>
                      <td class="text-center"><?php echo remove_junk($sale['added_by']); ?>
                      <?php
                        echo $user['username'] . $sale['added_by'];
                        ?>
                    </td>
                     
                      <td class="text-center">
                        <div class="btn-group">
                          <a href="edit_sale.php?id=<?php echo (int)$sale['id']; ?>" class="btn btn-warning btn-xs" title="Edit" data-toggle="tooltip">
                            <span class="glyphicon glyphicon-edit"></span>
                          </a>
                          <?php endif; ?>
                          <?php if ($user['user_level'] === '1'): ?>
                          <a href="#" class="btn btn-danger btn-xs" title="Delete" onclick="confirmDelete(<?php echo (int)$sale['id']; ?>)">
                            <span class="glyphicon glyphicon-trash"></span>
                          </a>
                          <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                      <script>
                        function confirmDelete(productId) {
                          Swal.fire({
                            title: 'Are you sure?',
                            text: 'You will not be able to recover this Sale!',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              // User confirmed the delete action
                              // Redirect to delete_product.php with the product ID
                              window.location.href = 'delete_sale.php?id=' + productId;
                            }
                          });
                        }
                      </script>
                          <input type="checkbox" class="delete-checkbox" value="<?php echo (int)$sale['id']; ?>">
                        </div>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(document).ready(function() {
    // Handle bulk delete button click event
    $('#bulk-delete-btn').click(function() {
      // Get the IDs of selected rows
      var selectedIds = [];
      $('.delete-checkbox:checked').each(function() {
        selectedIds.push($(this).val());
      });

      if (selectedIds.length === 0) {
        Swal.fire({
          icon: 'warning',
          title: 'Oops...',
          text: 'Please select at least one row to delete.'
        });
        return;
      }

      // Show confirmation dialog
      Swal.fire({
        title: 'Are you sure?',
        text: 'You will not be able to recover the selected sales!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete them!'
      }).then(function(result) {
        if (result.isConfirmed) {
          // User confirmed the delete action
          // Perform the bulk delete request
          $.ajax({
            url: 'bulk_delete_sales.php',
            type: 'POST',
            data: { ids: selectedIds },
            success: function(response) {
              // Handle the server response
              if (response.success) {
                Swal.fire({
                  icon: 'success',
                  title: 'Success',
                  text: 'Selected sales have been deleted.',
                  didClose: () => {
                    // Reload the page or update the table as needed
                    location.reload();
                  }
                });
              } else {
                Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'Error deleting selected sales. Please try again.'
                });
              }
            },
            error: function() {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error deleting selected sales. Please try again.'
              });
            }
          });
        }
      });
    });
  });
</script>
<?php include_once('layouts/footer.php'); ?>