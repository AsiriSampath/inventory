
<style>
    body {
        font-family: Arial, sans-serif;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 20px;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #f5f5f5;
    }

    h2 {
        margin-bottom: 20px;
        border-bottom: 2px solid #333;
        padding-bottom: 5px;
    }

    p {
        margin-top: 20px;
    }

    /* Additional styling for better readability on smaller screens */
    @media (max-width: 600px) {
        table {
            font-size: 14px;
        }
    }
</style>

<?php
    if (isset($_POST['search'])) {
        $search_query = $_POST['search_query'];

        // Include the database connection file
        include('db_connection.php');

        $sql = "SELECT s.id, s.qty, s.payment_method, s.delivery_method, s.delivery_ammount, s.discount_amount, s.description, s.price, s.customer_name, s.address, s.added_by, s.customer_email, s.customer_phone, s.date, p.name, u.username AS updated_by, user_id, place_by";
        $sql .= " FROM sales s";
        $sql .= " LEFT JOIN products p ON s.product_id = p.id";
        $sql .= " LEFT JOIN users u ON s.added_by = u.username";
        $sql .= " WHERE s.id LIKE '%$search_query%' OR s.date LIKE '%$search_query%' OR p.name LIKE '%$search_query%' OR s.customer_name LIKE '%$search_query%' OR s.customer_email LIKE '%$search_query%' OR s.address LIKE '%$search_query%' OR s.customer_phone LIKE '%$search_query%'";
        $sql .= " ORDER BY s.date DESC";

        $result = mysqli_query($connection, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo "<style>";
            echo "table { border-collapse: collapse; width: 100%; }";
            echo "th, td { padding: 8px; text-align: left; }";
            echo "th { background-color: #f2f2f2; }";
            echo "tr:nth-child(even) { background-color: #f2f2f2; }";
            echo "tr:hover { background-color: #ddd; }";
            echo "h2 { margin-bottom: 10px; }";
            echo "p { margin-top: 10px; }";
            echo "@media (max-width: 600px) { table { font-size: 14px; } }";
            echo "</style>";

            echo "<h2>Results:</h2>";
            echo "<table border='1'>";
            echo "<tr><th>ID</th><th>Date</th><th>Product Name</th><th>Customer Name</th><th>Quantity</th><th>Payment Method</th><th>Delivery Amount</th><th>Delivery Method</th><th>Discount Amount</th><th>Email</th><th>Phone Number</th><th>Address</th><th>Total</th><th>Sold By</th></tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['date'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['customer_name'] . "</td>";
                echo "<td>" . $row['qty'] . "</td>";
                echo "<td>" . $row['payment_method'] . "</td>";
                echo "<td>" . $row['delivery_ammount'] . "</td>";
                echo "<td>" . $row['delivery_method'] . "</td>";
                echo "<td>" . $row['discount_amount'] . "</td>";
                echo "<td>" . $row['customer_email'] . "</td>";
                echo "<td>" . $row['customer_phone'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "<td>" . $row['price'] . "</td>";
                echo "<td>" . $row['place_by'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No results found.</p>";
        }

        mysqli_close($connection);
    }
?>
