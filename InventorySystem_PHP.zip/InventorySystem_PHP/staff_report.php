<?php
$page_title = 'Staff Report';
require_once('includes/load.php');
page_require_level(2);
$all_staff = find_all_staff();
?>
<?php
if (isset($_POST['submit'])) {
  $req_dates = array('start-date', 'end-date', 'staff-id');
  validate_fields($req_dates);

  if (empty($errors)) {
      $start_date = remove_junk($db->escape($_POST['start-date']));
      $end_date = remove_junk($db->escape($_POST['end-date']));
      $staff_id = remove_junk($db->escape($_POST['staff-id']));
      $results = generate_staff_sales_report($staff_id, $start_date, $end_date);
  } else {
      $session->msg("d", $errors);
      redirect('staff_report.php', false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<style>
  /* Add the following CSS to your existing styles */
/* Apply fade-in animation to table rows */
@keyframes fadeIn {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply fade-in animation to even table rows */
@keyframes fadeInEven {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply fade-in animation to odd table rows */
@keyframes fadeInOdd {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply animation to table rows */
table.table-bordered tbody tr {
  animation: fadeIn 0.5s ease-in-out forwards;
}

/* Apply animation to even table rows */
table.table-bordered tbody tr:nth-child(even) {
  animation: fadeInEven 0.5s ease-in-out forwards;
}

/* Apply animation to odd table rows */
table.table-bordered tbody tr:nth-child(odd) {
  animation: fadeInOdd 0.5s ease-in-out forwards;
}

</style>
<div class="row">
  <div class="col-md-6">
    <div class="panel">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Generate Staff Report</span>
        </strong>
      </div>
      <div class="panel-body">
        <form class="clearfix" method="post" action="staff_report_process.php">
        <div class="form-group">
          <label class="form-label">Staff</label>
          <select class="form-control" name="staff-id" required>
            <option value="">Select Staff</option>
            <option value="all">All Staff</option>
            <?php foreach ($all_staff as $staff): ?>
              <option value="<?php echo $staff['id']; ?>"><?php echo $staff['name']; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
          <div class="form-group">
            <label class="form-label">Date Range</label>
            <div class="input-group">
              <input type="text" class="datepicker form-control" name="start-date" placeholder="From">
              <span class="input-group-addon"><i class="glyphicon glyphicon-menu-right"></i></span>
              <input type="text" class="datepicker form-control" name="end-date" placeholder="To">
            </div>
          </div>
          <div class="form-group">
            <button type="submit" name="submit" class="btn btn-primary">Generate Report <i class="fa fa-cogs" aria-hidden="true"></i></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<style>
  .panel {
  margin-top: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.panel-heading {
  background-color: #fdfaf3;
  border-bottom: 2px solid #364c6f;
  padding: 10px;
}

.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 18px;
}

.panel-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-label {
  font-weight: bold;
}

.form-control {
  width: 100%;
}

</style>
<?php include_once('layouts/footer.php'); ?>
