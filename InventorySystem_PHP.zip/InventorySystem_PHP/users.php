<?php
$page_title = 'All User';
require_once('includes/load.php');
?>

<?php
// Check what level user has permission to view this page
page_require_level(1);

// Pull out all users from the database
$all_users = find_all_user();
?>

<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Users</span>
        </strong>
        <a href="add_user.php" class="btn btn-primary pull-right">Add New <i class="fa fa-plus-square" aria-hidden="true"></i></a>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">ID</th>
              <th>Name</th>
              <th>Username</th>
              <th class="text-center" style="width: 10%;">User Role</th>
              <th class="text-center" style="width: 10%;">Status</th>
              <th style="width: 20%;">Last Login</th>
              <th class="text-center" style="width: 15%;">Email</th>
              <th class="text-center" style="width: 10%;">Phone No</th>
              <th class="text-center" style="width: 100px;">Actions</th>
            </tr>
          </thead>
            <tbody>
              <?php foreach ($all_users as $a_user) : ?>
                <?php
                // Check if the user is logged in or logged out
                $isLoggedOut = ($a_user['last_login'] === null);
                ?>
                <tr>
                  <td class="text-center"><?php echo $a_user['id']; ?></td>
                  <td><?php echo remove_junk(ucwords($a_user['name'])); ?></td>
                  <td><?php echo remove_junk(ucwords($a_user['username'])); ?></td>
                  <td class="text-center"><?php echo remove_junk(ucwords($a_user['group_name'])); ?></td>
                  <td class="text-center">
                    <?php if ($isLoggedOut) : ?>
                      <span class="label label-danger">Deactive</span>
                    <?php else : ?>
                      <span class="label label-success">Active</span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo read_date($a_user['last_login']); ?></td>
                  <td><?php echo remove_junk($a_user['email']); ?></td>
                  <td class="text-center"><?php echo remove_junk($a_user['phone_no']); ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <a href="edit_user.php?id=<?php echo (int)$a_user['id']; ?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                        <i class="glyphicon glyphicon-pencil"></i>
                      </a>
                      <a href="#" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove" onclick="confirmDelete(<?php echo (int) $a_user['id']; ?>)">
                        <i class="glyphicon glyphicon-remove"></i>
                      </a>
                      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                      <script>
                        function confirmDelete(userId) {
                          Swal.fire({
                            title: 'Are you sure?',
                            text: 'You will not be able to recover this user!',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                          }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href = 'delete_user.php?id=' + userId;
                            }
                          });
                        }
                      </script>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
